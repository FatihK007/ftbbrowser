using System.Windows;

namespace ftbBrowser;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += (_, args) =>
        {
            try
            {
                var dir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ftbBrowser");
                System.IO.Directory.CreateDirectory(dir);
                System.IO.File.WriteAllText(System.IO.Path.Combine(dir, "last-error.txt"), args.Exception.ToString());
            }
            catch { }
            MessageBox.Show("ftbBrowser beklenmeyen bir hata ile karşılaştı.\n\n" + args.Exception.Message, "ftbBrowser 2.5", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };
        base.OnStartup(e);
    }
}
