using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Controls.Primitives;
using System.IO;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace ftbBrowser;

public partial class MainWindow : Window
{
    private const string HomeUrl = "ftb://home";
    private const string Version = "2.5.2";
    private readonly Dictionary<TabItem, WebView2> _browsers = new();
    private readonly Dictionary<WebView2, string> _browserUrls = new();
    private readonly List<string> _history = new();
    private readonly List<FavoriteItem> _favorites = new();
    private readonly Stack<string> _closedTabs = new();
    private readonly List<DownloadItem> _downloads = new();
    private readonly string _dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ftbBrowser");
    private CoreWebView2Environment? _webEnvironment;
    private int _tabNumber;
    private bool _closing;
    private bool _starting;
    private readonly HashSet<TabItem> _pinnedTabs = new();
    private readonly HashSet<TabItem> _privateTabs = new();
    private readonly Dictionary<TabItem, string> _privateProfilePaths = new();
    private BrowserSettings _settings = new("system", true);
    private bool _darkTheme;
    private bool _updatingAddressBox;
    private string? _contextLink;
    private string? _contextSelection;
    private string? _activeDownloadPath;
    private long _lastDownloadSize = -1;
    private int _stableDownloadTicks;
    private readonly DispatcherTimer _downloadPollTimer = new() { Interval = TimeSpan.FromMilliseconds(500) };
    private bool _trueFullscreen;
    private WindowState _fullscreenPreviousState = WindowState.Normal;
    private TabItem? _dragTab;
    private Point _dragStartPoint;
    private readonly Dictionary<TabItem, string> _tabGroups = new();
    private bool _verticalTabs;
    private bool _sidebarOpen;
    private bool _commandPaletteOpen;

    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
        Closed += (_, _) => DisposeBrowsers();
        TabBar.PreviewMouseLeftButtonDown += TabBar_PreviewMouseLeftButtonDown;
        TabBar.PreviewMouseMove += TabBar_PreviewMouseMove;
        LoadSettings();
        LoadData();
        LoadDownloads();
        LoadLayoutPreferences();
        RefreshFavoritesBar();
        _downloadPollTimer.Tick += DownloadPollTimer_Tick;
    }

    private void SetInitialWindowSize()
    {
        var workArea = SystemParameters.WorkArea;
        const double preferredWidth = 1100;
        const double preferredHeight = 700;
        const double widthRatio = 0.90;
        const double heightRatio = 0.86;

        var targetWidth = Math.Min(preferredWidth, workArea.Width * widthRatio);
        var targetHeight = Math.Min(preferredHeight, workArea.Height * heightRatio);

        Width = Math.Max(MinWidth, targetWidth);
        Height = Math.Max(MinHeight, targetHeight);
        WindowState = WindowState.Normal;
        Left = workArea.Left + Math.Max(0, (workArea.Width - Width) / 2);
        Top = workArea.Top + Math.Max(0, (workArea.Height - Height) / 2);
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (_starting) return;
        _starting = true;
        try
        {
            SetInitialWindowSize();
            Directory.CreateDirectory(_dataDir);
            CleanupPrivateProfiles();
            try
            {
                _webEnvironment = await CoreWebView2Environment.CreateAsync(null, Path.Combine(_dataDir, "WebView2"));
            }
            catch
            {
                _webEnvironment = null;
            }

            var restored = _settings.RestoreSessionOnStartup ? GetRestorableSessionUrls() : new List<string>();
            if (restored.Count > 0)
            {
                foreach (var restoredUrl in restored) await CreateTabAsync(restoredUrl);
                ShowStatus(restored.Count + " sekme geri yüklendi");
            }
            else
            {
                await CreateTabAsync(HomeUrl);
                ShowStatus("ftbBrowser hazır");
            }
        }
        catch (Exception ex)
        {
            ShowStatus("Başlangıç hatası: " + ex.Message);
            WriteError(ex);
        }
        finally { _starting = false; }
    }

    private async Task CreateTabAsync(string url, bool isPrivate = false)
    {
        _tabNumber++;
        var tab = new TabItem { Tag = Guid.NewGuid().ToString("N") };
        string? privateProfilePath = null;
        if (isPrivate)
        {
            _privateTabs.Add(tab);
            privateProfilePath = Path.Combine(_dataDir, "Private", Guid.NewGuid().ToString("N"));
            _privateProfilePaths[tab] = privateProfilePath;
        }
        var browser = new WebView2();
        _browsers[tab] = browser;
        _browserUrls[browser] = string.IsNullOrWhiteSpace(url) ? HomeUrl : url;
        tab.Header = BuildTabHeader(isPrivate ? "Özel Sekme" : "Yeni Sekme", tab);
        TabBar.Items.Add(tab);
        TabBar.SelectedItem = tab;

        browser.NavigationStarting += (_, args) => Browser_NavigationStarting(tab, args);
        browser.NavigationCompleted += (_, args) => Browser_NavigationCompleted(tab, args);
        browser.CoreWebView2InitializationCompleted += (_, args) =>
        {
            if (!args.IsSuccess) ShowStatus("WebView2 başlatılamadı: " + (args.InitializationException?.Message ?? "bilinmeyen hata"));
        };

        try
        {
            CoreWebView2Environment? environment = _webEnvironment;
            if (isPrivate)
            {
                environment = await CoreWebView2Environment.CreateAsync(null, privateProfilePath!);
            }
            if (environment != null)
                await browser.EnsureCoreWebView2Async(environment);
            else
                await browser.EnsureCoreWebView2Async();

            ConfigureBrowser(browser);
            var core = browser.CoreWebView2!;
            core.DocumentTitleChanged += (_, _) => UpdateTabTitle(tab);
            core.WebMessageReceived += (_, args) => HandleHomeMessage(browser, args);
            core.PermissionRequested += Core_PermissionRequested;
            try { await core.AddScriptToExecuteOnDocumentCreatedAsync(ContextMenuScript); } catch { }
            core.NewWindowRequested += async (_, args) =>
            {
                args.Handled = true;
                if (!string.IsNullOrWhiteSpace(args.Uri)) await CreateTabAsync(args.Uri);
            };
            core.DownloadStarting += (_, args) =>
            {
                try
                {
                    var downloadsDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
                    Directory.CreateDirectory(downloadsDir);
                    var requested = string.IsNullOrWhiteSpace(args.ResultFilePath) ? "ftbBrowser-download" : Path.GetFileName(args.ResultFilePath);
                    var destination = GetUniqueFilePath(Path.Combine(downloadsDir, requested));
                    args.ResultFilePath = destination;
                }
                catch { }
                var path = args.ResultFilePath ?? string.Empty;
                var fileName = string.IsNullOrWhiteSpace(path) ? "İndiriliyor" : Path.GetFileName(path);
                if (!string.IsNullOrWhiteSpace(path))
                {
                    _downloads.RemoveAll(x => x.Path.Equals(path, StringComparison.OrdinalIgnoreCase));
                    _downloads.Insert(0, new DownloadItem(fileName, path, DateTime.Now.ToString("dd.MM.yyyy HH:mm")));
                    if (_downloads.Count > 40) _downloads.RemoveAt(_downloads.Count - 1);
                    SaveDownloads();
                }
                DownloadBar.Visibility = Visibility.Visible;
                _activeDownloadPath = path;
                _lastDownloadSize = -1;
                _stableDownloadTicks = 0;
                DownloadText.Text = "İndirme başladı: " + fileName;
                _downloadPollTimer.Start();
                ShowStatus("İndirme başladı");
            };
            BrowserHost.Content = browser;
            NavigateBrowser(browser, string.IsNullOrWhiteSpace(url) ? HomeUrl : url);
        }
        catch (Exception ex)
        {
            ShowStatus("WebView2 hatası: " + ex.Message);
            WriteError(ex);
            ShowStartupError(ex);
        }
    }

    private const string ContextMenuScript = """
(function(){
  document.addEventListener('contextmenu', function(e){
    try {
      var a = e.target && e.target.closest ? e.target.closest('a') : null;
      var selection = window.getSelection ? String(window.getSelection().toString() || '').trim() : '';
      var payload = { action:'context-menu', link:(a && a.href) || '', selection:selection };
      if (window.chrome && chrome.webview) chrome.webview.postMessage(JSON.stringify(payload));
      e.preventDefault();
    } catch (_) {}
  }, true);
})();
""";

    private void Core_PermissionRequested(object? sender, CoreWebView2PermissionRequestedEventArgs e)
    {
        try
        {
            var kind = e.PermissionKind.ToString();
            var origin = e.Uri ?? "Bu site";
            var answer = MessageBox.Show(this, origin + "\n\n" + kind + " izni istiyor.\nİzin verilsin mi?", "Site izni • ftbBrowser", MessageBoxButton.YesNo, MessageBoxImage.Question);
            e.State = answer == MessageBoxResult.Yes ? CoreWebView2PermissionState.Allow : CoreWebView2PermissionState.Deny;
        }
        catch { e.State = CoreWebView2PermissionState.Deny; }
    }

    private static void ConfigureBrowser(WebView2 browser)
    {
        var core = browser.CoreWebView2!;
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.AreDevToolsEnabled = true;
        core.Settings.IsStatusBarEnabled = false;
        core.Settings.IsZoomControlEnabled = true;
        core.Settings.AreDefaultScriptDialogsEnabled = true;
        core.Settings.IsGeneralAutofillEnabled = true;
        core.Settings.IsPasswordAutosaveEnabled = false;
    }

    private StackPanel BuildTabHeader(string title, TabItem tab)
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(5, 0, 2, 0) };
        var logo = new Border { Width = 27, Height = 18, CornerRadius = new CornerRadius(5), Background = Brush("#4D5DFF"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 7, 0) };
        logo.Child = new TextBlock { Text = "ftb", Foreground = Brushes.White, FontSize = 9, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        var text = new TextBlock { Text = title, Width = 132, TextTrimming = TextTrimming.CharacterEllipsis, VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5, FontWeight = FontWeights.SemiBold };
        text.SetResourceReference(TextBlock.ForegroundProperty, "IconText");
        var close = new Button { Content = "X", Width = 27, Height = 27, Padding = new Thickness(0), FontFamily = new FontFamily("Segoe UI"), FontSize = 15, FontWeight = FontWeights.SemiBold, Background = Brushes.Transparent, BorderThickness = new Thickness(0), ToolTip = "Sekmeyi kapat", Cursor = System.Windows.Input.Cursors.Hand };
        close.SetResourceReference(Button.ForegroundProperty, "Muted");
        close.Click += (_, _) => CloseTab(tab);
        panel.Children.Add(logo); panel.Children.Add(text); panel.Children.Add(close);
        return panel;
    }

    private void CloseTab(TabItem tab)
    {
        if (!_browsers.TryGetValue(tab, out var browser)) return;
        var url = CurrentUrl(browser);
        if (!string.IsNullOrWhiteSpace(url) && !url.StartsWith("ftb://", StringComparison.OrdinalIgnoreCase)) _closedTabs.Push(url);
        var wasSelected = TabBar.SelectedItem == tab;
        var wasPrivate = _privateTabs.Contains(tab);
        _browsers.Remove(tab);
        var privatePath = _privateProfilePaths.TryGetValue(tab, out var profile) ? profile : null;
        _privateProfilePaths.Remove(tab);
        _privateTabs.Remove(tab);
        _pinnedTabs.Remove(tab);
        _tabGroups.Remove(tab);
        _browserUrls.Remove(browser);
        TabBar.Items.Remove(tab);
        try { browser.Dispose(); } catch { }
        if (!string.IsNullOrWhiteSpace(privatePath))
        {
            try { if (Directory.Exists(privatePath)) Directory.Delete(privatePath, true); } catch { }
        }
        if (TabBar.Items.Count == 0) { _ = CreateTabAsync(HomeUrl); return; }
        if (wasSelected) { BrowserHost.Content = CurrentBrowser; UpdateAddressBar(); UpdateTabTitle(TabBar.SelectedItem as TabItem); }
        if (!wasPrivate) SaveSessionTabs();
    }

    private WebView2? CurrentBrowser => TabBar.SelectedItem is TabItem tab && _browsers.TryGetValue(tab, out var browser) ? browser : null;

    private string CurrentUrl(WebView2 browser)
        => _browserUrls.TryGetValue(browser, out var url) && !string.IsNullOrWhiteSpace(url)
            ? url
            : browser.Source?.ToString() ?? string.Empty;

    private void Navigate()
    {
        var input = AddressBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(input)) return;

        if (input.Equals("ftb://newtab", StringComparison.OrdinalIgnoreCase)) input = HomeUrl;
        if (File.Exists(input))
        {
            NavigateBrowser(CurrentBrowser, new Uri(Path.GetFullPath(input)).AbsoluteUri);
            return;
        }
        if (input.StartsWith("ftb://", StringComparison.OrdinalIgnoreCase))
        {
            NavigateBrowser(CurrentBrowser, input);
            return;
        }

        if (input.StartsWith("g:", StringComparison.OrdinalIgnoreCase))
            input = "https://www.google.com/search?q=" + Uri.EscapeDataString(input[2..].Trim());
        else if (input.StartsWith("yt:", StringComparison.OrdinalIgnoreCase))
            input = "https://www.youtube.com/results?search_query=" + Uri.EscapeDataString(input[3..].Trim());
        else if (input.StartsWith("wiki:", StringComparison.OrdinalIgnoreCase))
            input = "https://www.wikipedia.org/w/index.php?search=" + Uri.EscapeDataString(input[5..].Trim());
        else if (input.StartsWith("ddg:", StringComparison.OrdinalIgnoreCase))
            input = "https://duckduckgo.com/?q=" + Uri.EscapeDataString(input[4..].Trim());
        else if (!input.Contains("://", StringComparison.Ordinal))
            input = input.Contains('.') || input.Contains(':') ? "https://" + input : "https://www.google.com/search?q=" + Uri.EscapeDataString(input);

        if (Uri.TryCreate(input, UriKind.Absolute, out var uri) && (uri.Scheme is "http" or "https"))
            NavigateBrowser(CurrentBrowser, uri.ToString());
        else
            MessageBox.Show("Geçerli bir web adresi, ftb:// sayfası veya arama girin.", "ftbBrowser", MessageBoxButton.OK, MessageBoxImage.Warning);
    }

    private void NavigateBrowser(WebView2? browser, string url)
    {
        if (browser?.CoreWebView2 == null) return;
        if (string.Equals(url, "ftb://newtab", StringComparison.OrdinalIgnoreCase)) url = HomeUrl;

        if (url.StartsWith("ftb://", StringComparison.OrdinalIgnoreCase))
        {
            ShowFtbPage(browser, url);
            return;
        }

        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https")) return;
        _browserUrls[browser] = uri.ToString();
        browser.CoreWebView2.Navigate(uri.ToString());
    }

    private void ShowHomePage(WebView2? browser) => ShowFtbPage(browser, HomeUrl);

    private void ShowFtbPage(WebView2? browser, string url)
    {
        if (browser?.CoreWebView2 == null) return;
        var sourceUrl = CurrentUrl(browser);
        var route = url;
        var routeEnd = route.IndexOfAny(new[] { '?', '#' });
        if (routeEnd >= 0) route = route[..routeEnd];
        route = route.TrimEnd('/').ToLowerInvariant();
        var page = route switch
        {
            "ftb://home" or "ftb://newtab" => "home",
            "ftb://history" => "history",
            "ftb://favorites" => "favorites",
            "ftb://downloads" => "downloads",
            "ftb://settings" => "settings",
            "ftb://about" => "about",
            "ftb://diagnostics" => "diagnostics",
            "ftb://games" or "ftb://game-center" => "games",
            "ftb://tools" => "tools",
            "ftb://center" => "center",
            "ftb://search" or "ftb://search/" => "search",
            "ftb://game/snake" or "ftb://game-snake" => "game-snake",
            "ftb://game/tetris" or "ftb://game-tetris" => "game-tetris",
            "ftb://game/2048" or "ftb://game-2048" => "game-2048",
            "ftb://game/tictactoe" or "ftb://game-tictactoe" => "game-tictactoe",
            "ftb://game/memory" or "ftb://game-memory" => "game-memory",
            "ftb://game/pong" or "ftb://game-pong" => "game-pong",
            "ftb://game/space" or "ftb://game-space" => "game-space",
            "ftb://game/mines" or "ftb://game-mines" => "game-mines",
            "ftb://game/flappy" or "ftb://game-flappy" => "game-flappy",
            "ftb://game/breakout" or "ftb://game-breakout" => "game-breakout",
            "ftb://game/reflex" or "ftb://game-reflex" => "game-reflex",
            "ftb://game/quiz" or "ftb://game-quiz" => "game-quiz",
            "ftb://game/color" or "ftb://game-color" => "game-color",
            "ftb://game/word" or "ftb://game-word" => "game-word",
            "ftb://game/math" or "ftb://game-math" => "game-math",
            "ftb://game/dodge" or "ftb://game-dodge" => "game-dodge",
            "ftb://qr" => "qr",
            _ => "error"
        };
        var query = page == "search" ? GetQueryParameter(url, "q") : string.Empty;
        var searchPage = page == "search" ? ParsePositiveInt(GetQueryParameter(url, "page"), 0) : 0;
        _browserUrls[browser] = page == "search"
            ? "ftb://search" + (string.IsNullOrWhiteSpace(query) ? string.Empty : "?q=" + Uri.EscapeDataString(query) + (searchPage > 0 ? "&page=" + searchPage : string.Empty))
            : "ftb://" + page;
        var html = page switch
        {
            "home" => BuildHomeHtml(),
            "history" => BuildHistoryPageHtml(),
            "favorites" => BuildFavoritesPageHtml(),
            "downloads" => BuildDownloadsPageHtml(),
            "settings" => BuildSettingsPageHtml(),
            "about" => BuildAboutPageHtml(),
            "diagnostics" => LoadPageTemplate("diagnostics", null),
            "games" => LoadPageTemplate("games", null),
            "tools" => LoadPageTemplate("tools", null),
            "center" => BuildCenterPageHtml(),
            "search" => BuildSearchPageHtml(query, searchPage),
            "game-snake" => LoadPageTemplate("game-snake", null),
            "game-tetris" => LoadPageTemplate("game-tetris", null),
            "game-2048" => LoadPageTemplate("game-2048", null),
            "game-tictactoe" => LoadPageTemplate("game-tictactoe", null),
            "game-memory" => LoadPageTemplate("game-memory", null),
            "game-pong" => LoadPageTemplate("game-pong", null),
            "game-space" => LoadPageTemplate("game-space", null),
            "game-mines" => LoadPageTemplate("game-mines", null),
            "game-flappy" => LoadPageTemplate("game-flappy", null),
            "game-breakout" => LoadPageTemplate("game-breakout", null),
            "game-reflex" => LoadPageTemplate("game-reflex", null),
            "game-quiz" => LoadPageTemplate("game-quiz", null),
            "game-color" => LoadPageTemplate("game-color", null),
            "game-word" => LoadPageTemplate("game-word", null),
            "game-math" => LoadPageTemplate("game-math", null),
            "game-dodge" => LoadPageTemplate("game-dodge", null),
            "qr" => LoadPageTemplate("qr", sourceUrl),
            "error" => BuildErrorPageHtml(url),
            _ => BuildErrorPageHtml(url)
        };
        html = SanitizeLegacyIcons(html);
        browser.CoreWebView2.NavigateToString(html);
        // Populate web results after the ftb://search document finishes loading.
        // Calling ExecuteScriptAsync immediately after NavigateToString can race the DOM.
        if (TabBar.SelectedItem is TabItem tab && ReferenceEquals(_browsers[tab], browser))
        {
            AddressBox.Text = "ftb://" + page;
            UpdateSecurity("ftb://" + page);
            UpdateTabTitleFromText(tab, GetFtbPageTitle(page));
            UpdateWindowTitle();
            UpdateZoomLabel();
        }
        ShowStatus(GetFtbPageTitle(page) + " hazır");
    }

    private static string GetFtbPageTitle(string page) => page switch
    {
        "home" => "ftbBrowser Ana Sayfa",
        "history" => "Geçmiş • ftbBrowser",
        "favorites" => "Favoriler • ftbBrowser",
        "downloads" => "İndirilenler • ftbBrowser",
        "settings" => "Ayarlar • ftbBrowser",
        "about" => "ftbBrowser Hakkında",
        "diagnostics" => "Tanılama • ftbBrowser",
        "games" => "ftbGames • ftbBrowser",
        "tools" => "ftbTools • ftbBrowser",
        "center" => "FTB Merkezi • ftbBrowser",
        "search" => "ftb Search • ftbBrowser",
        "game-snake" => "Yılan • ftbGames",
        "game-tetris" => "Tetris • ftbGames",
        "game-2048" => "2048 • ftbGames",
        "game-tictactoe" => "XOX • ftbGames",
        "game-memory" => "Hafıza • ftbGames",
        "game-pong" => "Pong • ftbGames",
        "game-space" => "Uzay • ftbGames",
        "game-mines" => "Mayın Tarlası • ftbGames",
        "game-flappy" => "Flappy • ftbGames",
        "game-breakout" => "Breakout • ftbGames",
        "game-reflex" => "Refleks • ftbGames",
        "game-quiz" => "Felsefe Quiz • ftbGames",
        "game-color" => "Renk Refleksi • ftbGames",
        "game-word" => "Kelime Avı • ftbGames",
        "game-math" => "Matematik Sprint • ftbGames",
        "game-dodge" => "Kaçış • ftbGames",
        "qr" => "QR • ftbBrowser",
        "error" => "Sayfa bulunamadı • ftbBrowser",
        _ => "ftbBrowser"
    };

    private static string GameIconSvg(string gameId)
    {
        var common = "viewBox='0 0 48 48' xmlns='http://www.w3.org/2000/svg' aria-hidden='true' focusable='false'";
        var svg = gameId.ToLowerInvariant() switch
        {
            "snake" => $"<svg {common}><path d='M9 30c0-8 5-12 12-12h10c5 0 8-3 8-7' stroke='currentColor' stroke-width='4' stroke-linecap='round'/><path d='M9 30c0 6 4 10 10 10h8c5 0 9-4 9-9' stroke='currentColor' stroke-width='4' stroke-linecap='round'/><circle cx='39' cy='11' r='3' fill='currentColor'/></svg>",
            "tetris" => $"<svg {common}><rect x='6' y='6' width='10' height='10' rx='2' fill='currentColor'/><rect x='18' y='6' width='10' height='10' rx='2' fill='currentColor'/><rect x='30' y='6' width='10' height='10' rx='2' fill='currentColor'/><rect x='18' y='18' width='10' height='10' rx='2' fill='currentColor'/><rect x='18' y='30' width='10' height='10' rx='2' fill='currentColor'/><rect x='30' y='30' width='10' height='10' rx='2' fill='currentColor'/></svg>",
            "2048" => $"<svg {common}><rect x='6' y='6' width='16' height='16' rx='4' stroke='currentColor' stroke-width='3'/><rect x='26' y='26' width='16' height='16' rx='4' stroke='currentColor' stroke-width='3'/><path d='M12 14h4M13 34h11' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "tictactoe" => $"<svg {common}><path d='M18 6v36M30 6v36M6 18h36M6 30h36' stroke='currentColor' stroke-width='3'/><path d='M10 10l8 8m0-8l-8 8M32 32c0-3 2-5 5-5s5 2 5 5-2 5-5 5-5-2-5-5Z' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "memory" => $"<svg {common}><rect x='7' y='10' width='15' height='26' rx='4' stroke='currentColor' stroke-width='3'/><rect x='26' y='12' width='15' height='26' rx='4' stroke='currentColor' stroke-width='3'/><path d='M13 23h3M31 20h5M31 27h5' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "pong" => $"<svg {common}><rect x='7' y='10' width='5' height='28' rx='2.5' fill='currentColor'/><rect x='36' y='16' width='5' height='18' rx='2.5' fill='currentColor'/><circle cx='25' cy='25' r='4' fill='currentColor'/><path d='M12 25h9M29 25h7' stroke='currentColor' stroke-width='2'/></svg>",
            "space" => $"<svg {common}><path d='M24 5c8 7 11 15 11 24l-11 14-11-14c0-9 3-17 11-24Z' stroke='currentColor' stroke-width='3'/><circle cx='24' cy='21' r='4' stroke='currentColor' stroke-width='3'/><path d='M13 31l-7 4M35 31l7 4M24 43v3' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "mines" => $"<svg {common}><circle cx='24' cy='25' r='10' stroke='currentColor' stroke-width='3'/><path d='M24 5v7M24 38v7M4 25h7M37 25h7M10 11l5 5M33 34l5 5M38 12l-5 5M15 34l-5 5' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "flappy" => $"<svg {common}><path d='M8 27c3-8 13-12 22-8l7 3-7 4 7 6c-9 5-21 3-29-5Z' stroke='currentColor' stroke-width='3' stroke-linejoin='round'/><circle cx='31' cy='21' r='2.5' fill='currentColor'/><path d='M37 15l5-4' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "breakout" => $"<svg {common}><rect x='7' y='7' width='10' height='7' rx='2' fill='currentColor'/><rect x='19' y='7' width='10' height='7' rx='2' fill='currentColor'/><rect x='31' y='7' width='10' height='7' rx='2' fill='currentColor'/><circle cx='24' cy='27' r='4' fill='currentColor'/><path d='M11 39h26' stroke='currentColor' stroke-width='5' stroke-linecap='round'/></svg>",
            "reflex" => $"<svg {common}><path d='M28 5 12 27h11l-3 16 16-23H25l3-15Z' stroke='currentColor' stroke-width='3' stroke-linejoin='round'/></svg>",
            "quiz" => $"<svg {common}><circle cx='24' cy='24' r='18' stroke='currentColor' stroke-width='3'/><path d='M19 19c0-4 3-7 7-7s7 3 7 7c0 4-3 6-7 8v3M24 36h.01' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "color" => $"<svg {common}><circle cx='24' cy='24' r='16' stroke='currentColor' stroke-width='3'/><circle cx='18' cy='19' r='2.5' fill='currentColor'/><circle cx='28' cy='17' r='2.5' fill='currentColor'/><circle cx='32' cy='25' r='2.5' fill='currentColor'/><circle cx='20' cy='30' r='2.5' fill='currentColor'/></svg>",
            "word" => $"<svg {common}><rect x='6' y='10' width='36' height='28' rx='6' stroke='currentColor' stroke-width='3'/><path d='M13 28h8m4 0h10M13 20h6m4 0h12' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            "math" => $"<svg {common}><path d='M9 12h30M9 36h30M14 18l6 6-6 6M27 19l7 7m0-7-7 7' stroke='currentColor' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'/></svg>",
            "dodge" => $"<svg {common}><rect x='9' y='9' width='10' height='10' rx='3' fill='currentColor'/><rect x='29' y='29' width='10' height='10' rx='3' fill='currentColor'/><path d='M22 26l4-4m-4 4 4 4M26 22h-4m4 0v4' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>",
            _ => $"<svg {common}><circle cx='24' cy='24' r='18' stroke='currentColor' stroke-width='3'/><path d='M19 19c0-4 3-7 7-7s7 3 7 7c0 4-3 6-7 8v3M24 36h.01' stroke='currentColor' stroke-width='3' stroke-linecap='round'/></svg>"
        };
        return svg;
    }

    private string EnhanceGameHtml(string html, string page)
    {
        var gameId = page.StartsWith("game-", StringComparison.OrdinalIgnoreCase) ? page[5..] : page;
        html = Regex.Replace(html, @"<span\s+class=['""]emoji['""]>.*?</span>", "<span class='gameIcon'>" + GameIconSvg(gameId) + "</span>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        const string gameIconCss = "<style>.gameIcon{display:inline-grid;place-items:center;width:46px;height:46px;margin-right:8px;border-radius:13px;background:#eef1ff;color:#3f53d9;vertical-align:middle}.gameIcon svg{width:30px;height:30px;display:block}.gameIcon + *{vertical-align:middle}</style>";
        var headIndex = html.IndexOf("</head>", StringComparison.OrdinalIgnoreCase);
        if (headIndex >= 0) html = html.Insert(headIndex, gameIconCss);
        html = html.Replace("const id=(location.pathname.match(/game-([^./]+)\\.html/i)||[])[1]||'unknown';", $"const id='{gameId}';");
        html = html.Replace("const id=(location.pathname.match(/game-([^./]+)\\.html/i)||[])[1]||'unknown'", $"const id='{gameId}'");

        // Eski oyun şablonlarında bulunan istatistik scriptini kaldırıyoruz.
        // Böylece ortak 2.5.2 oyun katmanı aynı oyunu iki kez oynanmış saymaz.
        var scriptMatches = Regex.Matches(html, @"<script\b[^>]*>[\s\S]*?</script>", RegexOptions.IgnoreCase);
        for (var i = scriptMatches.Count - 1; i >= 0; i--)
        {
            var block = scriptMatches[i].Value;
            if (block.Contains("ftbGameStats", StringComparison.OrdinalIgnoreCase) && block.Contains("ftbGameRecent", StringComparison.OrdinalIgnoreCase))
                html = html.Remove(scriptMatches[i].Index, scriptMatches[i].Length);
        }

        var title = gameId switch
        {
            "snake" => "Yılan",
            "tetris" => "Tetris",
            "2048" => "2048",
            "tictactoe" => "XOX",
            "memory" => "Hafıza",
            "pong" => "Pong",
            "space" => "Uzay",
            "mines" => "Mayın Tarlası",
            "flappy" => "Flappy",
            "breakout" => "Breakout",
            "reflex" => "Refleks",
            "quiz" => "Felsefe Quiz",
            "color" => "Renk Refleksi",
            "word" => "Kelime Avı",
            "math" => "Matematik Sprint",
            "dodge" => "Kaçış",
            _ => gameId
        };
        var keyboard = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "snake", "tetris", "space", "flappy", "breakout", "pong", "dodge", "2048" };
        var dpad = keyboard.Contains(gameId) ? "<div class='ftb-dpad' aria-label='Oyun tuşları'><button data-key='ArrowUp' aria-label='Yukarı'>▲</button><div><button data-key='ArrowLeft' aria-label='Sol'>◀</button><button data-key='Space' aria-label='Boşluk'>●</button><button data-key='ArrowRight' aria-label='Sağ'>▶</button></div><button data-key='ArrowDown' aria-label='Aşağı'>▼</button></div>" : "";
        var overlay = $@"
<style>
#ftbGameBar{{position:fixed;left:50%;bottom:12px;transform:translateX(-50%);z-index:99999;display:flex;gap:7px;align-items:center;justify-content:center;flex-wrap:wrap;padding:8px 10px;background:rgba(16,27,46,.96);border:1px solid #344764;border-radius:14px;box-shadow:0 12px 35px rgba(0,0,0,.22);font-family:'Segoe UI','Segoe UI Symbol',Arial,sans-serif;max-width:calc(100vw - 24px)}}
#ftbGameBar button{{border:0!important;background:#fff!important;color:#172235!important;border-radius:9px!important;padding:8px 11px!important;font-size:12px!important;font-weight:800!important;cursor:pointer!important;min-height:34px}}
#ftbGameBar .primary{{background:#2563eb!important;color:#fff!important}}
#ftbGameBar .score{{color:#fff;font-size:11px;font-weight:700;padding:0 6px;white-space:nowrap;display:inline-flex;align-items:center;gap:6px}}#ftbGameBar .gameBarMark{{width:22px;height:22px;border-radius:7px;background:#2563eb;color:#fff;display:inline-grid;place-items:center;font-size:13px;font-weight:900}}
#ftbHelp{{position:fixed;inset:0;z-index:100000;display:none;place-items:center;background:rgba(5,12,24,.58);font-family:'Segoe UI','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji',Arial,sans-serif}}
#ftbHelp .box{{width:min(440px,90vw);background:#fff;color:#172235;border-radius:18px;padding:22px;box-shadow:0 25px 70px rgba(0,0,0,.3)}}
#ftbHelp h2{{margin:0 0 8px}}#ftbHelp p{{color:#64748b;line-height:1.55}}#ftbHelp .close{{background:#2563eb!important;color:#fff!important}}
.ftb-dpad{{position:fixed;left:14px;bottom:14px;z-index:99998;display:flex;flex-direction:column;align-items:center;gap:5px}}
.ftb-dpad div{{display:flex;gap:5px}}.ftb-dpad button{{width:42px;height:42px;padding:0!important;border:0!important;border-radius:12px!important;background:rgba(16,27,46,.96)!important;color:#fff!important;font-size:17px!important;box-shadow:0 8px 20px rgba(0,0,0,.2)}}
@media(max-width:700px){{#ftbGameBar{{left:10px;right:10px;transform:none;max-width:none}}.ftb-dpad{{left:10px;bottom:74px}}}}
</style>
<div id='ftbGameBar'><span class='score'><span class='gameBarMark'>◈</span> {Html(title)} • <span id='ftbPlayCount'>0</span> oynama</span><button class='primary' onclick='location.reload()'>↻ Yenile</button><button onclick='ftbRestart()'>▶ Yeniden</button><button onclick='ftbFull()'>⛶ Tam ekran</button><button onclick='ftbHelp()'>? Yardım</button><button onclick='ftbGo(&quot;ftb://games&quot;)'>Oyunlar</button><button onclick='ftbGo(&quot;ftb://home&quot;)'>Ana Sayfa</button></div>
<div id='ftbHelp'><div class='box'><h2>{Html(title)}</h2><p><b>R</b> yeniden başlatır. <b>Esc</b> oyun merkezine döner. <b>F</b> tam ekran yapar. Klavyeli oyunlarda ekrandaki yön tuşlarını da kullanabilirsin.</p><button class='close' onclick='ftbHelp()'>Kapat</button></div></div>
{dpad}
<script>
(function(){{
 const gameId={Js(gameId)};
 const stats=JSON.parse(localStorage.getItem('ftbGameStats')||'{{}}');
 stats[gameId]=(stats[gameId]||0)+1; localStorage.setItem('ftbGameStats',JSON.stringify(stats));
 const count=document.getElementById('ftbPlayCount'); if(count) count.textContent=stats[gameId];
 window.ftbGo=function(u){{if(window.chrome&&chrome.webview)chrome.webview.postMessage(JSON.stringify({{action:'navigate',url:u}}));}};
 window.ftbFull=function(){{try{{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.();}}catch{{}}}};
 window.ftbHelp=function(){{const x=document.getElementById('ftbHelp');if(x)x.style.display=x.style.display==='grid'?'none':'grid';}};
 window.ftbRestart=function(){{const b=[...document.querySelectorAll('button')].find(x=>/Yeni oyun|Yeni Oyun|Yeni Kelime|Başlat|Yeniden|Reset/i.test((x.textContent||''))&&!x.closest('#ftbGameBar'));if(b){{b.click();return;}}location.reload();}};
 document.addEventListener('keydown',e=>{{if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;if(e.key==='Escape'){{e.preventDefault();e.stopImmediatePropagation();ftbGo('ftb://games');return;}}if(e.key.toLowerCase()==='f'){{e.preventDefault();e.stopImmediatePropagation();ftbFull();return;}}if(e.key.toLowerCase()==='r'){{e.preventDefault();e.stopImmediatePropagation();ftbRestart();return;}}if(e.key==='?'||e.key==='/'){{e.preventDefault();e.stopImmediatePropagation();ftbHelp();}}}},true);
 document.querySelectorAll('.ftb-dpad button').forEach(b=>b.addEventListener('pointerdown',e=>{{e.preventDefault();const k=b.dataset.key;document.dispatchEvent(new KeyboardEvent('keydown',{{key:k,code:k==='Space'?'Space':k,bubbles:true}}));}}));
}})();
</script>";
        // Oyun arayüzünde renkli emoji fontuna bağımlılık yok. Sabit semboller kullanılır.
        if (html.Contains("</body>", StringComparison.OrdinalIgnoreCase))
            html = html.Replace("</body>", overlay + "</body>", StringComparison.OrdinalIgnoreCase);
        else
            html += overlay;
        return html;
    }

    private static string SanitizeLegacyIcons(string html)
    {
        // Eski sayfalardan kalan emoji karakterlerini güvenli, font-bağımsız sembollerle değiştir.
        return html.Replace("🎮", "◈").Replace("⚙️", "⚙").Replace("🔄", "↻").Replace("▶️", "▶").Replace("❓", "?").Replace("🏠", "⌂").Replace("🔒", "□").Replace("⭐", "★").Replace("📥", "⇩");
    }

    private string LoadPageTemplate(string page, string? currentUrl)
    {
        // Dahili sayfalar EXE içine EmbeddedResource olarak gömülür.
        // Kaynak adı SDK/RootNamespace tarafından değişse bile son ekten bulunur.
        var assembly = typeof(MainWindow).Assembly;
        try
        {
            var resourceNames = assembly.GetManifestResourceNames();
            var resourceName = resourceNames.FirstOrDefault(n =>
                n.EndsWith(".Pages." + page + ".html", StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(resourceName))
            {
                using var stream = assembly.GetManifestResourceStream(resourceName);
                if (stream != null)
                {
                    using var reader = new StreamReader(stream);
                    var embeddedHtml = reader.ReadToEnd();
                    if (page == "qr")
                        embeddedHtml = embeddedHtml.Replace("__URL__", Uri.EscapeDataString(currentUrl ?? HomeUrl));
                    return embeddedHtml;
                }
            }
        }
        catch (Exception ex)
        {
            WriteError(ex);
        }

        // Geliştirme sırasında klasörden çalıştırmayı da destekle.
        var file = Path.Combine(AppContext.BaseDirectory, "Pages", page + ".html");
        if (File.Exists(file))
        {
            var html = File.ReadAllText(file);
            if (page == "qr")
                html = html.Replace("__URL__", Uri.EscapeDataString(currentUrl ?? HomeUrl));
            return html;
        }

        return FtbPageShell("Sayfa bulunamadı",
            "<div class='heroCard'><div><h1>Dahili sayfa bulunamadı.</h1><p>" +
            Html(page) + " sayfası EXE içine gömülmemiş veya Pages klasöründe bulunamadı.</p></div></div>");
    }

    private string BuildHomeHtml()
    {
        string FavCards()
        {
            var items = _favorites.Take(6).Select(f => $"<button class='tile' onclick='go({Js(f.Url)})'><span class='tileIcon'>★</span><span><b>{Html(f.Title)}</b><small>{Html(GetHost(f.Url))}</small></span></button>");
            return string.Join("", items);
        }

        var history = _history.Take(5).Select(h => $"<button class='history' onclick='go({Js(h)})'><span class='historyDot'></span><span>{Html(h)}</span></button>");
        var fav = _favorites.Count == 0 ? "<div class='empty'>Favoriye eklediğin siteler burada görünecek.</div>" : FavCards();
        var hist = _history.Count == 0 ? "<div class='empty'>Henüz ziyaret geçmişin yok.</div>" : string.Join("", history);
        var daily = new[] { ("snake", "Yılan"), ("tetris", "Tetris"), ("2048", "2048"), ("pong", "Pong"), ("flappy", "Flappy"), ("breakout", "Breakout"), ("reflex", "Refleks"), ("quiz", "Felsefe Quiz") };
        var dayIndex = DateTime.Today.DayOfYear % daily.Length;
        var dailyId = daily[dayIndex].Item1;
        var dailyName = daily[dayIndex].Item2;

        return "<!doctype html>" +
               "<html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
               "<style>" +
               "*{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:'Segoe UI',Arial,sans-serif}" +
               "body{background:radial-gradient(circle at 85% 8%,#dfe5ff 0,rgba(223,229,255,0) 30%),linear-gradient(135deg,#f6f8fc 0%,#edf2f8 48%,#e9edf7 100%);color:#162033}.shell{max-width:1180px;margin:auto;padding:52px 44px 40px}" +
               ".hero{display:flex;justify-content:space-between;gap:30px;align-items:flex-start}.brand{display:flex;gap:18px;align-items:center}.mark{width:92px;height:58px;border-radius:16px;background:linear-gradient(135deg,#4d5dff,#7180ff);color:#fff;display:grid;place-items:center;font-size:25px;font-weight:900;letter-spacing:-.08em;line-height:1;box-shadow:0 18px 40px rgba(77,93,255,.22);flex:none}.heroTitle{font-size:39px;line-height:1.04;letter-spacing:-.035em;margin:0}.heroLogoNote{font-size:12px;color:#8995a8;margin-top:7px}" +
               ".eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:.18em;color:#6c7890;font-weight:800;margin-bottom:6px}h1{font-size:39px;line-height:1.04;letter-spacing:-.035em;margin:0}.sub{margin-top:10px;font-size:15px;color:#708096}.version{padding:8px 12px;border-radius:999px;background:rgba(255,255,255,.7);border:1px solid #dce4ed;color:#67758b;font-size:12px;font-weight:700}" +
               ".search{margin-top:30px;padding:8px;display:flex;gap:7px;background:rgba(255,255,255,.88);border:1px solid #d8e0eb;border-radius:18px;box-shadow:0 18px 50px rgba(52,68,95,.09);backdrop-filter:blur(10px)}.search input{flex:1;border:0;outline:0;background:transparent;padding:15px 16px;font-size:17px;color:#172235}.search button{border:0;border-radius:13px;padding:0 24px;background:#4d5dff;color:#fff;font-weight:700;cursor:pointer}.chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}.chip{border:1px solid #dde4ef;background:rgba(255,255,255,.65);color:#56647a;border-radius:999px;padding:8px 12px;cursor:pointer}" +
               ".row{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin-top:30px}.panel{background:rgba(255,255,255,.7);border:1px solid #dde5ef;border-radius:18px;padding:20px;box-shadow:0 9px 25px rgba(49,63,87,.05)}.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}.title{font-size:12px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:#6d7a8f}.muted{font-size:12px;color:#96a0af}.tiles{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.tile{display:flex;align-items:center;gap:11px;border:1px solid #dde4ee;border-radius:14px;background:rgba(255,255,255,.88);padding:13px;text-align:left;cursor:pointer;color:#172235}.tile:hover{transform:translateY(-1px);border-color:#a6b2f8}.tileIcon{width:32px;height:32px;border-radius:10px;background:#eef1ff;color:#4d5dff;display:grid;place-items:center}.tile b{display:block;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px}.tile small{display:block;color:#8a96a8;margin-top:3px}.history{width:100%;display:flex;gap:10px;align-items:center;background:rgba(255,255,255,.55);border:1px solid #e1e7ef;border-radius:11px;padding:11px 12px;margin:6px 0;text-align:left;color:#48566c;cursor:pointer}.history span:last-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.historyDot{width:7px;height:7px;border-radius:50%;background:#7e8cf6;flex:none}.empty{padding:15px;border:1px dashed #cdd6e3;border-radius:12px;color:#8996a9;font-size:13px}.daily{margin-top:22px;display:flex;align-items:center;justify-content:space-between;gap:18px;padding:18px 20px;background:rgba(255,255,255,.76);border:1px solid #dfe6ef;border-radius:18px;box-shadow:0 8px 24px rgba(49,63,87,.05)}.dailyKicker{font-size:10px;letter-spacing:.16em;font-weight:800;color:#6c7890;margin-bottom:5px}.daily strong{display:block;font-size:18px}.daily span{display:block;color:#7f8b9f;font-size:12px;margin-top:4px}.dailyBtn{border:0;border-radius:11px;padding:10px 18px;background:#4d5dff;color:#fff;font-weight:700;cursor:pointer}.features{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:18px}.feature{background:rgba(255,255,255,.58);border:1px solid #e0e6ef;border-radius:15px;padding:15px}.feature strong{display:block;font-size:13px;margin-bottom:5px}.feature span{font-size:12px;color:#7b8799;line-height:1.4}.quickTools{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:16px}.quick{border:1px solid #dde4ee;border-radius:14px;background:rgba(255,255,255,.72);padding:14px;text-align:left;cursor:pointer;color:#172235}.quick:hover{transform:translateY(-1px);border-color:#a6b2f8}.quick b{display:block;font-size:12px;margin-bottom:5px}.quick span{font-size:11px;color:#8390a2;line-height:1.35}.footer{display:flex;justify-content:space-between;gap:20px;margin-top:25px;color:#8995a6;font-size:12px}" +
               "@media(max-width:980px){.quickTools{grid-template-columns:repeat(3,1fr)}}@media(max-width:850px){.shell{padding:34px 22px}.hero{flex-direction:column}.row{grid-template-columns:1fr}.features{grid-template-columns:1fr}.quickTools{grid-template-columns:repeat(2,1fr)}h1{font-size:32px}}" +
               "</style></head><body><div class='shell'>" +
               "<div class='hero'><div><div class='brand'><div class='mark'>ftb</div><div><div class='eyebrow'>YENİ SEKME</div><h1 class='heroTitle'>ftbBrowser</h1><div class='heroLogoNote'>Kendi ana sayfan. Arama, favoriler ve araçlar burada.</div></div></div><div class='sub'>Temiz sekmeler, hızlı erişim ve sade bir tarayıcı deneyimi.</div></div><div class='version'>2.5.2</div></div>" +
               "<form class='search' onsubmit='searchWeb();return false'><input id='q' autofocus autocomplete='off' placeholder='Web adresi veya arama yazın'><button type='submit'>Ara</button></form>" +
               "<div class='chips'><button class='chip' onclick='go(\"https://www.google.com\")'>Google</button><button class='chip' onclick='go(\"https://www.youtube.com\")'>YouTube</button><button class='chip' onclick='go(\"https://www.wikipedia.org\")'>Wikipedia</button><button class='chip' onclick='go(\"https://www.github.com\")'>GitHub</button></div>" +
               "<div class='row'><section class='panel'><div class='head'><div class='title'>Favoriler</div><div class='muted'>Hızlı erişim</div></div><div class='tiles'>" + fav + "</div></section>" +
               "<section class='panel'><div class='head'><div class='title'>Son ziyaretler</div><div class='muted'>Geçmiş</div></div>" + hist + "</section></div>" +
               "<div class='daily'><div><div class='dailyKicker'>GÜNÜN OYUNU</div><strong>" + dailyName + "</strong><span>Bugün için seçilen yerleşik oyun.</span></div><button class='dailyBtn' onclick='go(\"ftb://game/\" + dailyId)'>Oyna</button></div>" +
               "<div class='features'><div class='feature'><strong>Hızlı</strong><span>Adres çubuğundan doğrudan arama ve hızlı sekme yönetimi.</span></div><div class='feature'><strong>Güvenli görünüm</strong><span>HTTPS bağlantılarında güvenlik durumunu adres çubuğunda gösterir.</span></div><div class='feature'><strong>Kişisel</strong><span>Favoriler, geçmiş ve sana özel başlangıç ekranı.</span></div></div>" +
               "<div class='quickTools'><button class='quick' onclick='go(\"ftb://history\")'><b>Geçmiş</b><span>Ziyaret edilen sayfalar</span></button><button class='quick' onclick='go(\"ftb://favorites\")'><b>Favoriler</b><span>Kaydedilen siteler</span></button><button class='quick' onclick='go(\"ftb://downloads\")'><b>İndirilenler</b><span>Son dosyalar</span></button><button class='quick' onclick='go(\"ftb://settings\")'><b>Ayarlar</b><span>Gizlilik ve tarayıcı</span></button><button class='quick' onclick='go(\"ftb://games\")'><b>ftbGames</b><span>16 mini oyun</span></button><button class='quick' onclick='act(\"restore-session\")'><b>Son oturum</b><span>Sekmeleri geri yükle</span></button></div>" +
               "<div class='footer'><span>ftbBrowser • Küçük • Hızlı • Sade</span><span>g: Google • yt: YouTube • wiki: Wikipedia • ddg: DuckDuckGo</span></div>" +
               "</div><script>function msg(o){chrome.webview.postMessage(JSON.stringify(o))}function go(u){msg({action:'navigate',url:u})}function act(a){msg({action:a})}function searchWeb(){var q=document.getElementById('q').value.trim();if(!q)return;var u=(q.indexOf('://')>0)?q:((q.indexOf('.')>=0)?'https://'+q:'https://www.google.com/search?q='+encodeURIComponent(q));go(u)}document.getElementById('q').addEventListener('keydown',e=>{if(e.key==='Enter')searchWeb()});</script></body></html>";
    }

    private string BuildErrorPageHtml(string badUrl)
    {
        return FtbPageShell("Sayfa bulunamadı", "<div class='heroCard'><div class='logo'>ftb</div><div><div class='kicker'>ftbBrowser</div><h1>Bu ftb sayfası bulunamadı.</h1><p>Adres: " + Html(badUrl) + "</p></div></div><div class='cards'><button class='card' onclick=\"go('ftb://games')\"><strong>ftbGames</strong><span>Oyun merkezine dön.</span></button><button class='card' onclick=\"go('ftb://home')\"><strong>Ana Sayfa</strong><span>ftbBrowser ana sayfasını aç.</span></button></div>");
    }

    private string BuildFtbPageHtml(string page)
    {
        var body = page switch
        {
            "history" => BuildHistoryPageHtml(),
            "favorites" => BuildFavoritesPageHtml(),
            "downloads" => BuildDownloadsPageHtml(),
            "settings" => BuildSettingsPageHtml(),
            "about" => BuildAboutPageHtml(),
            _ => BuildHomeHtml()
        };
        return body;
    }

    private string BuildHistoryPageHtml()
    {
        var items = _history.Count == 0
            ? "<div class='empty'>Geçmiş boş.</div>"
            : string.Join("", _history.Take(80).Select((u, i) => "<button class='listItem' onclick='go(" + Js(u) + ")'><span class='index'>" + (i + 1) + "</span><span><b>" + Html(GetHost(u)) + "</b><small>" + Html(u) + "</small></span></button>"));
        return FtbPageShell("Geçmiş", "<div class='headRow'><div><div class='kicker'>ftbBrowser</div><h1>Geçmiş</h1><p>Son ziyaret edilen sayfalar.</p></div><button class='secondary' onclick=\"act('clear-history')\">Geçmişi temizle</button></div><div class='list'>" + items + "</div>");
    }

    private string BuildFavoritesPageHtml()
    {
        var items = _favorites.Count == 0
            ? "<div class='empty'>Henüz favori eklenmedi.</div>"
            : string.Join("", _favorites.Take(100).Select((f, i) => "<button class='listItem' onclick='go(" + Js(f.Url) + ")'><span class='index'>★</span><span><b>" + Html(f.Title) + "</b><small>" + Html(f.Url) + "</small></span></button>"));
        return FtbPageShell("Favoriler", "<div class='headRow'><div><div class='kicker'>ftbBrowser</div><h1>Favoriler</h1><p>Kaydettiğin sayfalara hızlı erişim.</p></div><button class='secondary' onclick=\"act('clear-favorites')\">Favorileri temizle</button></div><div class='list'>" + items + "</div>");
    }

    private string BuildDownloadsPageHtml()
    {
        var items = _downloads.Count == 0
            ? "<div class='empty'>Henüz kayıtlı indirme yok.</div>"
            : string.Join("", _downloads.Take(40).Select(d => "<button class='listItem' onclick='openFile(" + Js(d.Path) + ")'><span class='index'>⇩</span><span><b>" + Html(d.FileName) + "</b><small>" + Html(d.Time) + " • " + Html(d.Path) + "</small></span></button>"));
        var open = "<button class='secondary' onclick=\"act('open-downloads')\">İndirme klasörünü aç</button>";
        return FtbPageShell("İndirilenler", "<div class='headRow'><div><div class='kicker'>ftbBrowser</div><h1>İndirilenler</h1><p>ftbBrowser'ın kaydettiği son dosyalar.</p></div>" + open + "</div><div class='list'>" + items + "</div>");
    }

    private string BuildSettingsPageHtml()
    {
        var sessionText = _settings.RestoreSessionOnStartup ? "Açık" : "Kapalı";
        var body = "<div class='headRow'><div><div class='kicker'>ftbBrowser 2.5.2</div><h1>Ayarlar</h1><p>Gizlilik, görünüm, oturum ve yedekleme.</p></div></div>" +
                   "<div class='cards emojiCards'>" +
                   "<button class='card' onclick=\"act('clear-web-data')\"><strong>Web verilerini temizle</strong><span>Çerezler, önbellek ve WebView2 web verileri.</span></button>" +
                   "<button class='card' onclick=\"act('clear-history')\"><strong>Geçmişi temizle</strong><span>ftbBrowser'ın tuttuğu ziyaret geçmişini sil.</span></button>" +
                   "<button class='card' onclick=\"act('clear-favorites')\"><strong>Favorileri temizle</strong><span>Kaydedilmiş favorileri kaldır.</span></button>" +
                   "<button class='card' onclick=\"act('restore-session')\"><strong>Son oturumu geri yükle</strong><span>Kapanıştan önceki web sekmelerini yeni sekmeler olarak aç.</span></button>" +
                   "<button class='card' onclick=\"act('toggle-session')\"><strong>Oturum geri yükleme: " + sessionText + "</strong><span>Tarayıcı açılırken son web sekmelerini otomatik geri yükler.</span></button>" +
                   "<button class='card' onclick=\"act('reset-zoom')\"><strong>Yakınlaştırmayı sıfırla</strong><span>Aktif sekmeyi yüzde 100'e getir.</span></button>" +
                   "<button class='card' onclick=\"act('open-downloads')\"><strong>İndirme klasörü</strong><span>Windows Downloads klasörünü aç.</span></button>" +
                   "<button class='card' onclick=\"act('export-backup')\"><strong>Ayarları dışa aktar</strong><span>Geçmiş, favoriler ve görünüm ayarlarını JSON olarak yedekle.</span></button>" +
                   "<button class='card' onclick=\"act('import-backup')\"><strong>Yedeği içe aktar</strong><span>Daha önce alınan ftbBrowser JSON yedeğini geri yükle.</span></button>" +
                   "<button class='card' onclick=\"act('open-error-log')\"><strong>Hata günlüğü</strong><span>Son hata kaydını Not Defteri ile aç.</span></button>" +
                   "<button class='card' onclick=\"act('open-data-folder')\"><strong>Veri klasörü</strong><span>ftbBrowser yerel veri klasörünü aç.</span></button>" +
                   "<button class='card' onclick=\"act('theme')\"><strong>Tema</strong><span>Açık, koyu, mavi, mor veya yeşil tema arasında geçiş yap.</span></button>" +
                   "</div>";
        const string extraCss = ".emojiCards .card strong{font-size:15px}.emojiCards .card{min-height:106px}";
        return FtbPageShell("Ayarlar", body, extraCss, "");
    }

    private string BuildSearchPageHtml(string query, int page = 0)
    {
        query = query?.Trim() ?? string.Empty;
        page = Math.Max(0, page);
        var entries = new List<(string Title, string Url, string Description, string Kind)>
        {
            ("ftbBrowser Ana Sayfa", "ftb://home", "Ana sayfa ve hızlı erişim.", "FTB"),
            ("FTB Search", "ftb://search", "ftbBrowser içindeki sayfa, oyun, araç, geçmiş ve favori araması.", "Arama"),
            ("ftbGames", "ftb://games", "16 yerleşik mini oyun ve oyun merkezi.", "Oyun"),
            ("ftbTools", "ftb://tools", "Hesap makinesi, dönüştürücü, zamanlayıcı, not ve metin araçları.", "Araç"),
            ("Geçmiş", "ftb://history", "Ziyaret edilen web sayfaları.", "FTB"),
            ("Favoriler", "ftb://favorites", "Kaydedilmiş web sayfaları.", "FTB"),
            ("İndirilenler", "ftb://downloads", "İndirilen dosyalar.", "FTB"),
            ("Ayarlar", "ftb://settings", "Gizlilik, veri temizleme ve tarayıcı ayarları.", "FTB"),
            ("QR Kod", "ftb://qr", "Geçerli sayfa için QR kodu.", "Araç"),
            ("Tanılama", "ftb://diagnostics", "WebView2 ve sistem bilgileri.", "Araç"),
            ("Yılan", "ftb://game/snake", "Klasik yılan oyunu.", "Oyun"),
            ("Tetris", "ftb://game/tetris", "Klasik blok yerleştirme oyunu.", "Oyun"),
            ("2048", "ftb://game/2048", "Sayı birleştirme oyunu.", "Oyun"),
            ("XOX", "ftb://game/tictactoe", "Tek veya iki oyunculu XOX.", "Oyun"),
            ("Hafıza", "ftb://game/memory", "Kart eşleştirme oyunu.", "Oyun"),
            ("Pong", "ftb://game/pong", "Klasik raket oyunu.", "Oyun"),
            ("Uzay", "ftb://game/space", "Uzayda ateş et ve engellerden kaç.", "Oyun"),
            ("Mayın Tarlası", "ftb://game/mines", "Mayınları bul ve işaretle.", "Oyun"),
            ("Flappy", "ftb://game/flappy", "Engellerin arasından geç.", "Oyun"),
            ("Breakout", "ftb://game/breakout", "Topla blokları kır.", "Oyun"),
            ("Refleks", "ftb://game/reflex", "Tepki süreni ölç.", "Oyun"),
            ("Felsefe Quiz", "ftb://game/quiz", "Felsefe bilgisi quiz'i.", "Oyun"),
            ("Renk Refleksi", "ftb://game/color", "Doğru renkte doğru anda tıkla.", "Oyun"),
            ("Kelime Avı", "ftb://game/word", "Karışık harflerden kelime oluştur.", "Oyun"),
            ("Matematik Sprint", "ftb://game/math", "Hızlı matematik soruları.", "Oyun"),
            ("Kaçış", "ftb://game/dodge", "Engellerden kaç.", "Oyun")
        };
        foreach (var h in _history.Take(100)) if (IsWebUrl(h)) entries.Add((GetHost(h), h, "Geçmişte ziyaret edildi.", "Geçmiş"));
        foreach (var f in _favorites.Take(100)) if (IsWebUrl(f.Url)) entries.Add((string.IsNullOrWhiteSpace(f.Title) ? GetHost(f.Url) : f.Title, f.Url, "Favorilerden web sayfası.", "Favori"));

        var terms = query.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var allMatches = entries.Select(e =>
        {
            var hay = e.Title + " " + e.Description + " " + e.Url + " " + e.Kind;
            var score = terms.Sum(t => hay.Contains(t, StringComparison.OrdinalIgnoreCase) ? 2 : 0);
            if (!string.IsNullOrWhiteSpace(query) && e.Title.StartsWith(query, StringComparison.OrdinalIgnoreCase)) score += 6;
            if (!string.IsNullOrWhiteSpace(query) && e.Url.Contains(query, StringComparison.OrdinalIgnoreCase)) score += 2;
            return new { E = e, Score = score };
        }).Where(x => string.IsNullOrWhiteSpace(query) || x.Score > 0)
          .OrderByDescending(x => x.Score)
          .ThenBy(x => x.E.Title, StringComparer.CurrentCultureIgnoreCase)
          .Select(x => x.E)
          .DistinctBy(x => x.Url, StringComparer.OrdinalIgnoreCase)
          .ToList();

        const int pageSize = 12;
        var totalPages = Math.Max(1, (int)Math.Ceiling(allMatches.Count / (double)pageSize));
        page = Math.Min(page, totalPages - 1);
        var visible = allMatches.Skip(page * pageSize).Take(pageSize).ToList();
        var items = visible.Count == 0
            ? "<div class='empty'>FTB içinde eşleşen sonuç yok.<br><small>Web sitesi açmak için adres çubuğuna doğrudan alan adını yazabilirsin.</small></div>"
            : string.Join("", visible.Select((e, i) => "<button class='result' onclick='go(" + Js(e.Url) + ")'><span class='rank'>" + (page * pageSize + i + 1) + "</span><span><b>" + Html(e.Title) + "</b><small>" + Html(e.Url) + "</small><em>" + Html(e.Kind + " • " + e.Description) + "</em></span></button>"));

        var prev = Math.Max(0, page - 1);
        var next = Math.Min(totalPages - 1, page + 1);
        var q = Html(query).Replace("'", "&#39;");
        var body = "<div class='searchTop'><div class='brandLine'><div class='logo'>ftb</div><div><div class='kicker'>FTB SEARCH</div><div class='brandText'>Dahili arama</div></div></div><div class='engineBadge'>FTB Index</div></div>" +
                   "<form class='searchBox' onsubmit='doSearch();return false'><span class='searchIcon'>?</span><input id='sq' value='" + q + "' placeholder='ftbBrowser içinde ara...' autocomplete='off'><button type='submit'>Ara</button></form>" +
                   "<div class='searchNav'><span class='navTab active'>FTB</span><span class='smallMeta'>Sayfa " + (page + 1) + " / " + totalPages + " • " + allMatches.Count + " sonuç</span></div>" +
                   "<div class='engineNotice'><span class='dot'></span><span>FTB içeriğinde bul ve istersen aynı sorguyu tek tıkla Google'da ara.</span><button onclick='googleIt()'>Google'da ara</button></div>" +
                   "<div class='resultHead'><b>Sonuçlar</b><span>" + visible.Count + " gösteriliyor</span></div><div class='results'>" + items + "</div>" +
                   "<div class='pager'><button onclick='goPage(" + prev + ")' " + (page == 0 ? "disabled" : "") + ">‹ Önceki</button><span>Sayfa " + (page + 1) + " / " + totalPages + "</span><button onclick='goPage(" + next + ")' " + (page >= totalPages - 1 ? "disabled" : "") + ">Sonraki ›</button></div>" +
                   "<div class='searchFooter'>FTB Search 2.5.2 • Yerel indeks + Google bağlantısı</div>";
        const string css = ".searchTop{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}.brandLine{display:flex;align-items:center;gap:12px}.brandText{font-size:15px;font-weight:800}.engineBadge{border:1px solid #dce4ef;border-radius:999px;padding:7px 12px;font-size:11px;font-weight:800;color:#4d5dff;background:#f6f8ff}.searchBox{display:flex;align-items:center;gap:8px;background:#fff;border:1px solid #d7dfeb;border-radius:20px;padding:7px;margin-bottom:14px;box-shadow:0 12px 34px rgba(20,38,65,.08)}.searchBox input{flex:1;border:0;outline:0;padding:14px 6px;font-size:17px;min-width:0}.searchIcon{font-size:24px;padding-left:11px}.searchBox button{border:0;border-radius:14px;background:#2563eb;color:#fff;font-weight:800;padding:11px 19px;cursor:pointer}.searchNav{display:flex;align-items:center;gap:12px;border-bottom:1px solid #e4e9f0;margin-bottom:18px}.navTab{padding:10px 13px;color:#2563eb;font-size:12px;font-weight:800;border-bottom:2px solid #2563eb}.smallMeta{font-size:11px;color:#7b8799}.engineNotice{display:flex;gap:8px;align-items:center;border:1px solid #e5ebf3;background:#f9fbfe;border-radius:11px;padding:10px 12px;color:#728095;font-size:11px;margin-bottom:20px}.engineNotice button{margin-left:auto;border:0;border-radius:9px;background:#2563eb;color:#fff;padding:7px 11px;font-weight:800;cursor:pointer}.engineNotice button{margin-left:auto;border:0;border-radius:9px;background:#2563eb;color:#fff;padding:7px 11px;font-weight:800;cursor:pointer}.dot{width:7px;height:7px;border-radius:50%;background:#2563eb;display:block;flex:none}.resultHead{display:flex;justify-content:space-between;align-items:center;margin:12px 0;color:#7b8799;font-size:11px}.results{display:flex;flex-direction:column;gap:8px}.result{display:flex;gap:12px;width:100%;border:1px solid #dde4ee;background:#fff;border-radius:13px;padding:13px;text-align:left;cursor:pointer}.result:hover{border-color:#aebaff}.result .rank{width:29px;height:29px;border-radius:9px;background:#eef2ff;color:#4e61eb;display:grid;place-items:center;font-weight:900;flex:none}.result b,.result small,.result em{display:block}.result b{font-size:13px}.result small{color:#3e7e55;margin-top:4px;font-size:11px;word-break:break-all}.result em{font-style:normal;color:#8491a4;margin-top:5px;font-size:11px}.empty{padding:18px;border:1px dashed #cfd8e5;border-radius:13px;color:#8995a7;background:#fff}.pager{display:flex;align-items:center;justify-content:center;gap:12px;padding:22px 0}.pager button{border:1px solid #d9e1eb;background:#fff;border-radius:10px;padding:8px 12px;color:#3159c8;font-weight:700;cursor:pointer}.pager button:disabled{opacity:.4;cursor:default}.searchFooter{margin-top:14px;padding:10px 0;color:#9aa4b3;font-size:10px}@media(max-width:650px){.searchBox{flex-wrap:wrap}.searchBox input{min-width:160px}.searchTop{gap:10px}.engineBadge{display:none}}";
        var js = "function post(o){if(window.chrome&&chrome.webview)chrome.webview.postMessage(JSON.stringify(o))}function go(u){post({action:'navigate',url:u})}function doSearch(){var q=document.getElementById('sq').value.trim();if(q)post({action:'google-search',query:q})}function googleIt(){doSearch()}function goPage(p){var q=document.getElementById('sq').value.trim();go('ftb://search?q='+encodeURIComponent(q)+'&page='+p)}document.getElementById('sq').focus();";
        return FtbPageShell("FTB Search", body, css, js);
    }

    private static string BuildCenterPageHtml()
    {
        var body = "<div class='headRow'><div><div class='kicker'>ftbBrowser 2.5.2</div><h1>FTB Merkezi</h1><p>Tarayıcının ana özelliklerine tek yerden ulaş.</p></div></div>" +
                   "<div class='cards'>" +
                   "<button class='card' onclick=\"go('ftb://home')\"><strong>Ana Sayfa</strong><span>Hızlı erişim ve Google araması.</span></button>" +
                   "<button class='card' onclick=\"go('ftb://games')\"><strong>Oyunlar</strong><span>16 yerleşik oyun ve skorlar.</span></button>" +
                   "<button class='card' onclick=\"go('ftb://tools')\"><strong>Araçlar</strong><span>Hesaplama, QR, not ve metin araçları.</span></button>" +
                   "<button class='card' onclick=\"go('ftb://history')\"><strong>Geçmiş</strong><span>Ziyaret edilen sayfalar.</span></button>" +
                   "<button class='card' onclick=\"go('ftb://favorites')\"><strong>Favoriler</strong><span>Kaydettiğin siteler.</span></button>" +
                   "<button class='card' onclick=\"go('ftb://downloads')\"><strong>İndirilenler</strong><span>Kaydedilen dosyalar.</span></button>" +
                   "<button class='card' onclick=\"go('ftb://settings')\"><strong>Ayarlar</strong><span>Tema, gizlilik ve oturum.</span></button>" +
                   "<button class='card' onclick=\"go('ftb://diagnostics')\"><strong>Tanılama</strong><span>WebView2 ve sistem bilgileri.</span></button>" +
                   "</div>";
        return FtbPageShell("FTB Merkezi", body);
    }

    private List<string> GetLocalSearchSuggestions(string query)
    {
        if (string.IsNullOrWhiteSpace(query)) return [];
        var terms = query.Trim();
        var names = new[] { "ftbBrowser", "ftbGames", "ftbTools", "Yılan", "Tetris", "2048", "XOX", "Hafıza", "Pong", "Uzay", "Mayın Tarlası", "Flappy", "Breakout", "Refleks", "Felsefe Quiz", "Renk Refleksi", "Kelime Avı", "Matematik Sprint", "Kaçış", "Geçmiş", "Favoriler", "İndirilenler", "Ayarlar", "QR Kod", "Tanılama" };
        return names.Where(x => x.Contains(terms, StringComparison.CurrentCultureIgnoreCase)).Take(7).ToList();
    }

    private static string BuildAboutPageHtml()
    {
        return FtbPageShell("Hakkında", "<div class='heroCard'><div class='logo'>ftb</div><div><div class='kicker'>Küçük • Hızlı • Sade</div><h1>ftbBrowser 2.5.2</h1><p>WebView2 tabanlı Windows tarayıcısı. Normal metin aramaları Google'a gider; FTB Search ise yerel ftb içeriklerini hızlıca bulur.</p></div></div><div class='cards'><div class='card static'><strong>Özel ftb:// sayfaları</strong><span>home • history • favorites • downloads • settings • about</span></div><div class='card static'><strong>Akıllı adres çubuğu</strong><span>URL, normal arama veya g: / yt: / wiki: / ddg: komutları.</span></div><div class='card static'><strong>Klavye odaklı</strong><span>Ctrl+L, Ctrl+T, Ctrl+W, Ctrl+Shift+T ve daha fazlası.</span></div></div>");
    }

    private static string FtbPageShell(string title, string body)
        => FtbPageShell(title, body, string.Empty, string.Empty);

    private static string FtbPageShell(string title, string body, string extraCss, string extraScript)
    {
        const string baseCss = "*{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:'Segoe UI','Segoe UI Symbol',Arial,sans-serif;background:#f4f7fb;color:#172235}.wrap{max-width:1100px;margin:0 auto;padding:46px 38px 50px}.kicker{font-size:11px;text-transform:uppercase;letter-spacing:.18em;color:#6c7890;font-weight:800;margin-bottom:6px}.headRow{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:24px}h1{font-size:34px;letter-spacing:-.03em;margin:0}.headRow p{margin:8px 0 0;color:#748197}.secondary{border:0;border-radius:12px;padding:10px 14px;background:#eaf0ff;color:#4a5cff;font-weight:700;cursor:pointer}.list{display:flex;flex-direction:column;gap:8px}.listItem{display:flex;align-items:center;gap:13px;width:100%;padding:14px 16px;border:1px solid #dde4ee;border-radius:14px;background:#fff;text-align:left;color:#172235;cursor:pointer}.listItem:hover{border-color:#b4bfff;transform:translateY(-1px)}.listItem .index{width:30px;height:30px;border-radius:10px;background:#eef1ff;color:#4d5dff;display:grid;place-items:center;font-weight:800;flex:none}.listItem b{display:block;font-size:13px}.listItem small{display:block;margin-top:4px;color:#8491a4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.empty{padding:18px;border:1px dashed #cfd8e5;border-radius:14px;color:#8995a7;background:#fff}.cards{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.card{border:1px solid #dde4ee;border-radius:16px;background:#fff;padding:18px;text-align:left;cursor:pointer;box-shadow:0 7px 20px rgba(49,63,87,.04)}.card:hover{border-color:#b5bffb;transform:translateY(-1px)}.card strong{display:block;font-size:14px;margin-bottom:6px}.card span{font-size:12px;color:#7c899a;line-height:1.45}.card.static{cursor:default}.heroCard{display:flex;gap:18px;align-items:center;border:1px solid #dde4ee;border-radius:18px;background:#fff;padding:22px;box-shadow:0 10px 28px rgba(49,63,87,.05);margin-bottom:16px}.heroCard p{color:#748197}.logo{width:42px;height:27px;border-radius:6px;background:#2563eb;color:#fff;display:grid;place-items:center;font-size:15px;font-weight:800;letter-spacing:-.06em;flex:none}@media(max-width:760px){.wrap{padding:28px 18px}.headRow{flex-direction:column}.cards{grid-template-columns:1fr}}";
        const string baseScript = "function post(o){if(window.chrome&&chrome.webview)chrome.webview.postMessage(JSON.stringify(o))}function go(u){post({action:'navigate',url:u})}function act(a){post({action:a})}function openFile(p){post({action:'open-file',path:p})}";
        return "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>" + Html(title) + "</title><style>" + baseCss + extraCss + "</style></head><body><main class='wrap'>" + body + "</main><script>" + baseScript + extraScript + "</script></body></html>";
    }

    private void HandleHomeMessage(WebView2 sourceBrowser, CoreWebView2WebMessageReceivedEventArgs args)
    {
        try
        {
            var payload = args.TryGetWebMessageAsString();
            if (string.IsNullOrWhiteSpace(payload)) return;
            using var doc = JsonDocument.Parse(payload);
            var root = doc.RootElement;
            if (!root.TryGetProperty("action", out var actionElement)) return;
            var action = actionElement.GetString();
            switch (action)
            {
                case "navigate":
                    if (root.TryGetProperty("url", out var urlEl))
                    {
                        var url = urlEl.GetString();
                        if (!string.IsNullOrWhiteSpace(url)) NavigateBrowser(sourceBrowser, url);
                    }
                    break;
                case "search-web":
                    if (root.TryGetProperty("query", out var queryEl))
                    {
                        var query = queryEl.GetString()?.Trim() ?? string.Empty;
                        NavigateBrowser(sourceBrowser, string.IsNullOrWhiteSpace(query) ? "ftb://search" : "ftb://search?q=" + Uri.EscapeDataString(query));
                    }
                    break;
                case "google-search":
                    if (root.TryGetProperty("query", out var googleQueryEl))
                    {
                        var googleQuery = googleQueryEl.GetString()?.Trim() ?? string.Empty;
                        if (!string.IsNullOrWhiteSpace(googleQuery))
                            NavigateBrowser(sourceBrowser, "https://www.google.com/search?q=" + Uri.EscapeDataString(googleQuery));
                    }
                    break;
                case "command":
                    if (root.TryGetProperty("name", out var commandNameEl)) ExecuteCommand(commandNameEl.GetString() ?? string.Empty);
                    break;
                case "search-suggest":
                    {
                        var suggestionQuery = root.TryGetProperty("query", out var suggestionEl) ? suggestionEl.GetString()?.Trim() : string.Empty;
                        _ = SendSearchSuggestionsAsync(sourceBrowser, suggestionQuery);
                        break;
                    }
                case "open-downloads":
                    OpenDownloads();
                    break;
                case "open-file":
                    if (root.TryGetProperty("path", out var pathEl)) OpenDownloadedFile(pathEl.GetString());
                    break;
                case "clear-web-data":
                    ClearBrowsingData_Click(this, new RoutedEventArgs());
                    break;
                case "clear-history":
                    _history.Clear(); SaveData(); ShowStatus("Geçmiş temizlendi");
                    NavigateBrowser(sourceBrowser, "ftb://history");
                    break;
                case "clear-favorites":
                    _favorites.Clear(); SaveData(); RefreshFavoritesBar(); ShowStatus("Favoriler temizlendi");
                    NavigateBrowser(sourceBrowser, "ftb://favorites");
                    break;
                case "restore-session":
                    RestoreSessionTabs();
                    break;
                case "reset-zoom":
                    if (sourceBrowser != null) sourceBrowser.ZoomFactor = 1.0; UpdateZoomLabel(); ShowStatus("Yakınlaştırma %100");
                    break;
                case "new-tab":
                    _ = CreateTabAsync(HomeUrl);
                    break;
                case "reload-current":
                    sourceBrowser?.Reload();
                    break;
                case "open-error-log":
                    OpenErrorLog_Click(this, new RoutedEventArgs());
                    break;
                case "open-data-folder":
                    OpenDataFolder_Click(this, new RoutedEventArgs());
                    break;
                case "toggle-theme":
                    ToggleTheme();
                    break;
                case "toggle-session":
                    ToggleSessionRestore();
                    NavigateBrowser(sourceBrowser, "ftb://settings");
                    break;
                case "export-backup":
                    ExportBackup_Click(this, new RoutedEventArgs());
                    break;
                case "import-backup":
                    ImportBackup_Click(this, new RoutedEventArgs());
                    break;
                case "theme":
                    ToggleTheme();
                    NavigateBrowser(sourceBrowser, "ftb://settings");
                    break;
                case "clear-downloads":
                    ClearDownloadHistory();
                    NavigateBrowser(sourceBrowser, "ftb://downloads");
                    break;
                case "toggle-vertical-tabs":
                    ToggleVerticalTabs();
                    NavigateBrowser(sourceBrowser, "ftb://settings");
                    break;
                case "open-command-palette":
                    ShowCommandPalette();
                    break;
                case "open-sidebar":
                    ToggleSidebar();
                    break;
            }
        }
        catch (Exception ex) { ShowStatus("ftb sayfası işlemi başarısız: " + ex.Message); }
    }

    private async Task SendSearchSuggestionsAsync(WebView2 targetBrowser, string? query)
    {
        var browser = targetBrowser;
        if (browser?.CoreWebView2 == null) return;
        try
        {
            var suggestions = GetLocalSearchSuggestions(query ?? string.Empty);
            var json = JsonSerializer.Serialize(suggestions);
            await browser.CoreWebView2.ExecuteScriptAsync("if(window.showSuggestions)window.showSuggestions(" + json + ");");
        }
        catch { }
    }

    private void ToggleVerticalTabs()
    {
        _verticalTabs = !_verticalTabs;
        TabBar.SetResourceReference(FrameworkElement.StyleProperty, _verticalTabs ? "VerticalTabControlStyle" : "HorizontalTabControlStyle");
        ShowStatus(_verticalTabs ? "Dikey sekmeler açıldı" : "Yatay sekmeler açıldı");
        SaveLayoutPreferences();
    }

    private string LayoutFile => Path.Combine(_dataDir, "layout.json");

    private void LoadLayoutPreferences()
    {
        try
        {
            if (!File.Exists(LayoutFile)) return;
            var data = JsonSerializer.Deserialize<LayoutPreferences>(File.ReadAllText(LayoutFile));
            _verticalTabs = data?.VerticalTabs ?? false;
            TabBar.SetResourceReference(FrameworkElement.StyleProperty, _verticalTabs ? "VerticalTabControlStyle" : "HorizontalTabControlStyle");
        }
        catch { _verticalTabs = false; }
    }

    private void SaveLayoutPreferences()
    {
        try
        {
            Directory.CreateDirectory(_dataDir);
            File.WriteAllText(LayoutFile, JsonSerializer.Serialize(new LayoutPreferences(_verticalTabs), new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void ToggleSidebar()
    {
        _sidebarOpen = !_sidebarOpen;
        Sidebar.Visibility = _sidebarOpen ? Visibility.Visible : Visibility.Collapsed;
        ShowStatus(_sidebarOpen ? "Yan panel açıldı" : "Yan panel kapatıldı");
    }

    private void SidebarClose_Click(object sender, RoutedEventArgs e) => ToggleSidebar();
    private void SidebarHome_Click(object sender, RoutedEventArgs e) { ToggleSidebar(); NavigateBrowser(CurrentBrowser, HomeUrl); }
    private void SidebarHistory_Click(object sender, RoutedEventArgs e) { ToggleSidebar(); NavigateBrowser(CurrentBrowser, "ftb://history"); }
    private void SidebarFavorites_Click(object sender, RoutedEventArgs e) { ToggleSidebar(); NavigateBrowser(CurrentBrowser, "ftb://favorites"); }
    private void SidebarDownloads_Click(object sender, RoutedEventArgs e) { ToggleSidebar(); NavigateBrowser(CurrentBrowser, "ftb://downloads"); }
    private void SidebarGames_Click(object sender, RoutedEventArgs e) { ToggleSidebar(); NavigateBrowser(CurrentBrowser, "ftb://games"); }
    private void SidebarTools_Click(object sender, RoutedEventArgs e) { ToggleSidebar(); NavigateBrowser(CurrentBrowser, "ftb://tools"); }
    private void SidebarSettings_Click(object sender, RoutedEventArgs e) { ToggleSidebar(); NavigateBrowser(CurrentBrowser, "ftb://settings"); }

    private void ShowCommandPalette()
    {
        CommandPalettePopup.IsOpen = true;
        _commandPaletteOpen = true;
        CommandBox.Text = string.Empty;
        RefreshCommandList();
        CommandBox.Focus();
    }

    private void CloseCommandPalette()
    {
        _commandPaletteOpen = false;
        CommandPalettePopup.IsOpen = false;
    }

    private void CommandBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) => RefreshCommandList();

    private void CommandBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            CloseCommandPalette();
            e.Handled = true;
            return;
        }
        if (e.Key == Key.Down)
        {
            if (CommandList.Items.Count > 0) CommandList.SelectedIndex = Math.Min(CommandList.Items.Count - 1, CommandList.SelectedIndex + 1);
            e.Handled = true;
            return;
        }
        if (e.Key == Key.Up)
        {
            if (CommandList.Items.Count > 0) CommandList.SelectedIndex = Math.Max(0, CommandList.SelectedIndex - 1);
            e.Handled = true;
            return;
        }
        if (e.Key == Key.Enter && CommandList.SelectedItem is string command)
        {
            ExecuteCommand(command);
            e.Handled = true;
        }
    }

    private void RefreshCommandList()
    {
        var filter = CommandBox.Text?.Trim() ?? string.Empty;
        var commands = new List<string>
        {
            "Yeni sekme", "Özel sekme", "Geçmiş", "Favoriler", "İndirilenler", "ftbGames", "ftbTools", "Ayarlar",
            "Komut paletini kapat", "Yan panel", "Dikey sekmeler", "Sesi aç / kapat", "Okuma modu", "Ekran görüntüsü",
            "PDF kaydet", "Yazdır", "Google'da ara", "Sekmeyi çoğalt", "Kapatılan sekmeyi aç", "Tam ekran"
        };
        CommandList.ItemsSource = commands.Where(x => string.IsNullOrWhiteSpace(filter) || x.Contains(filter, StringComparison.CurrentCultureIgnoreCase)).ToList();
        if (CommandList.Items.Count > 0) CommandList.SelectedIndex = 0;
        else CommandList.SelectedIndex = -1;
    }

    private void CommandList_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && CommandList.SelectedItem is string command)
        {
            ExecuteCommand(command);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            CloseCommandPalette();
            e.Handled = true;
        }
    }

    private void ExecuteCommand(string command)
    {
        switch (command.ToLowerInvariant())
        {
            case "yeni sekme": _ = CreateTabAsync(HomeUrl); break;
            case "özel sekme": _ = CreateTabAsync(HomeUrl, true); break;
            case "geçmiş": NavigateBrowser(CurrentBrowser, "ftb://history"); break;
            case "favoriler": NavigateBrowser(CurrentBrowser, "ftb://favorites"); break;
            case "indirilenler": NavigateBrowser(CurrentBrowser, "ftb://downloads"); break;
            case "ftbgames": NavigateBrowser(CurrentBrowser, "ftb://games"); break;
            case "ftbtools": NavigateBrowser(CurrentBrowser, "ftb://tools"); break;
            case "ayarlar": NavigateBrowser(CurrentBrowser, "ftb://settings"); break;
            case "komut paletini kapat": break;
            case "yan panel": ToggleSidebar(); break;
            case "dikey sekmeler": ToggleVerticalTabs(); break;
            case "sesi aç / kapat": ToggleMute_Click(this, new RoutedEventArgs()); break;
            case "okuma modu": ReaderMode_Click(this, new RoutedEventArgs()); break;
            case "ekran görüntüsü": Screenshot_Click(this, new RoutedEventArgs()); break;
            case "pdf kaydet": SaveAsPdf_Click(this, new RoutedEventArgs()); break;
            case "yazdır": Print_Click(this, new RoutedEventArgs()); break;
            case "google'da ara":
                AddressBox.Focus(); AddressBox.SelectAll();
                break;
            case "sekmeyi çoğalt": DuplicateCurrentTab(); break;
            case "kapatılan sekmeyi aç": ReopenClosedTab(); break;
            case "tam ekran": ToggleFullscreen(); break;
            case "sekmeyi ara": SearchTabs(); break;
            case "ftb merkezi": NavigateBrowser(CurrentBrowser, "ftb://center"); break;
        }
        CloseCommandPalette();
    }

    private void SearchTabs()
    {
        var dialog = new Window
        {
            Owner = this,
            Width = 440,
            Height = 150,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            ResizeMode = ResizeMode.NoResize,
            Title = "Sekme ara • ftbBrowser",
            Background = (Brush)FindResource("Surface")
        };
        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(new TextBlock { Text = "Açık sekmeler içinde ara", FontSize = 13, FontWeight = FontWeights.SemiBold, Foreground = (Brush)FindResource("Text") });
        var box = new TextBox { Margin = new Thickness(0, 10, 0, 10), Height = 34, VerticalContentAlignment = VerticalAlignment.Center };
        panel.Children.Add(box);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var cancel = new Button { Content = "İptal", Padding = new Thickness(14, 7, 14, 7), Margin = new Thickness(0, 0, 8, 0) };
        var ok = new Button { Content = "Ara", Padding = new Thickness(14, 7, 14, 7), IsDefault = true };
        cancel.Click += (_, _) => dialog.DialogResult = false;
        ok.Click += (_, _) => dialog.DialogResult = true;
        buttons.Children.Add(cancel); buttons.Children.Add(ok); panel.Children.Add(buttons);
        dialog.Content = panel;
        box.Focus();
        if (dialog.ShowDialog() != true) return;
        var query = box.Text.Trim();
        if (string.IsNullOrWhiteSpace(query)) return;
        var match = TabBar.Items.OfType<TabItem>().FirstOrDefault(tab =>
        {
            if (tab.Header is not StackPanel header || header.Children.Count < 2 || header.Children[1] is not TextBlock text) return false;
            return text.Text.Contains(query, StringComparison.CurrentCultureIgnoreCase);
        });
        if (match != null) { TabBar.SelectedItem = match; ShowStatus("Sekme bulundu"); }
        else ShowStatus("Eşleşen sekme bulunamadı");
    }

    private async Task ToggleMediaPlayPauseAsync()
    {
        var browser = CurrentBrowser;
        if (browser?.CoreWebView2 == null) return;
        try
        {
            await browser.CoreWebView2.ExecuteScriptAsync("Array.from(document.querySelectorAll('video,audio')).forEach(m=>m.paused?m.play():m.pause());");
            ShowStatus("Medya durumu değiştirildi");
        }
        catch (Exception ex) { ShowStatus("Medya kontrolü başarısız: " + ex.Message); }
    }

    private async Task StopMediaAsync()
    {
        var browser = CurrentBrowser;
        if (browser?.CoreWebView2 == null) return;
        try
        {
            await browser.CoreWebView2.ExecuteScriptAsync("Array.from(document.querySelectorAll('video,audio')).forEach(m=>{m.pause();m.currentTime=0;});");
            ShowStatus("Medya durduruldu");
        }
        catch (Exception ex) { ShowStatus("Medya durdurulamadı: " + ex.Message); }
    }

    private void AddressBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_updatingAddressBox || !AddressBox.IsKeyboardFocusWithin) return;
        var query = AddressBox.Text.Trim();
        if (query.Length == 0 || query.StartsWith("ftb://", StringComparison.OrdinalIgnoreCase))
        {
            AddressSuggestionPopup.IsOpen = false;
            return;
        }
        var suggestions = new List<string>();
        suggestions.Add("Google: " + query);
        if (query.Contains(' ', StringComparison.Ordinal)) suggestions.Add("g: " + query);
        foreach (var item in _history.Concat(_favorites.Select(x => x.Url)).Where(x => x.Contains(query, StringComparison.OrdinalIgnoreCase)).Distinct(StringComparer.OrdinalIgnoreCase).Take(6))
            suggestions.Add(item);
        AddressSuggestionList.ItemsSource = suggestions.Distinct(StringComparer.OrdinalIgnoreCase).Take(12).ToList();
        AddressSuggestionPopup.IsOpen = AddressSuggestionList.Items.Count > 0;
    }

    private void AddressSuggestionList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (AddressSuggestionList.SelectedItem is not string value) return;
        var text = value.StartsWith("Google: ", StringComparison.OrdinalIgnoreCase) ? value[8..] : value;
        _updatingAddressBox = true;
        AddressBox.Text = text;
        _updatingAddressBox = false;
        AddressSuggestionPopup.IsOpen = false;
        Navigate();
        AddressSuggestionList.SelectedItem = null;
    }

    private static string GetUniqueFilePath(string path)
    {
        if (!File.Exists(path)) return path;
        var directory = Path.GetDirectoryName(path) ?? string.Empty;
        var name = Path.GetFileNameWithoutExtension(path);
        var extension = Path.GetExtension(path);
        for (var i = 1; i < 10000; i++)
        {
            var candidate = Path.Combine(directory, name + " (" + i + ")" + extension);
            if (!File.Exists(candidate)) return candidate;
        }
        return Path.Combine(directory, name + " " + Guid.NewGuid().ToString("N") + extension);
    }

    private void Navigate(string url)
    {
        AddressBox.Text = url;
        Navigate();
    }

    private static string GetQueryParameter(string url, string key)
    {
        try
        {
            var q = url.IndexOf("?", StringComparison.Ordinal);
            if (q < 0) return string.Empty;
            foreach (var part in url[(q + 1)..].Split('&', StringSplitOptions.RemoveEmptyEntries))
            {
                var bits = part.Split('=', 2);
                if (bits.Length == 2 && string.Equals(Uri.UnescapeDataString(bits[0]), key, StringComparison.OrdinalIgnoreCase))
                    return Uri.UnescapeDataString(bits[1].Replace("+", " "));
            }
        }
        catch { }
        return string.Empty;
    }

    private static int ParsePositiveInt(string? value, int fallback = 0)
    {
        return int.TryParse(value, out var result) && result >= 0 ? result : fallback;
    }

    private static string Js(string value) => JsonSerializer.Serialize(value);
    private static string Html(string value) => System.Net.WebUtility.HtmlEncode(value);
    private static string GetHost(string value) => Uri.TryCreate(value, UriKind.Absolute, out var uri) ? uri.Host : value;

    private void UpdateAddressBar()
    {
        var browser = CurrentBrowser;
        var url = browser == null ? HomeUrl : CurrentUrl(browser);
        _updatingAddressBox = true;
        AddressBox.Text = string.IsNullOrWhiteSpace(url) ? HomeUrl : url;
        _updatingAddressBox = false;
        AddressSuggestionPopup.IsOpen = false;
        UpdateSecurity(AddressBox.Text);
        UpdateZoomLabel(); UpdateWindowTitle();
    }

    private void UpdateSecurity(string url)
    {
        if (url.StartsWith("ftb://", StringComparison.OrdinalIgnoreCase))
        {
            var page = url[6..].Trim('/').ToLowerInvariant();
            SecurityText.Text = "⌂ ftb sayfa";
            SecurityText.Foreground = Brushes.SlateBlue;
            SecurityPill.Background = Brush("#EEF3FA");
            DomainText.Text = "ftb://" + (string.IsNullOrWhiteSpace(page) ? "home" : page);
            return;
        }
        if (Uri.TryCreate(url, UriKind.Absolute, out var uri))
        {
            if (uri.Scheme.Equals("https", StringComparison.OrdinalIgnoreCase))
            {
                SecurityText.Text = "✓ Güvenli";
                SecurityText.Foreground = Brushes.SeaGreen;
                SecurityPill.Background = Brush("#EEF8F2");
            }
            else if (uri.Scheme.Equals("http", StringComparison.OrdinalIgnoreCase))
            {
                SecurityText.Text = "! Güvenli değil";
                SecurityText.Foreground = Brushes.OrangeRed;
                SecurityPill.Background = Brush("#FFF1F0");
            }
            else
            {
                SecurityText.Text = "• Bağlantı";
                SecurityText.Foreground = Brushes.DarkOrange;
                SecurityPill.Background = Brush("#FFF7E8");
            }
            DomainText.Text = string.IsNullOrWhiteSpace(uri.Host) ? uri.Scheme : uri.Host;
        }
    }

    private void UpdateWindowTitle()
    {
        var title = CurrentBrowser?.CoreWebView2?.DocumentTitle;
        Title = string.IsNullOrWhiteSpace(title) ? "ftbBrowser " + Version : title + " - ftbBrowser " + Version;
    }

    private void UpdateTabTitle(TabItem? tab)
    {
        if (tab == null || !_browsers.TryGetValue(tab, out var browser)) return;
        var title = string.IsNullOrWhiteSpace(browser.CoreWebView2?.DocumentTitle) ? "Yeni Sekme" : browser.CoreWebView2!.DocumentTitle;
        UpdateTabTitleFromText(tab, _pinnedTabs.Contains(tab) ? "PIN • " + RemovePinPrefix(title) : RemovePinPrefix(title));
        if (TabBar.SelectedItem == tab) { UpdateWindowTitle(); UpdateAddressBar(); }
    }

    private static string RemovePinPrefix(string text)
    {
        const string pinPrefix = "PIN • ";
        return text.StartsWith(pinPrefix, StringComparison.Ordinal) ? text[pinPrefix.Length..] : text.TrimStart();
    }

    private static void UpdateTabTitleFromText(TabItem? tab, string title)
    {
        if (tab?.Header is StackPanel panel && panel.Children.Count > 1 && panel.Children[1] is TextBlock text) text.Text = title;
    }

    private void AddHistory(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return;
        if (uri.Scheme is not ("http" or "https")) return;
        _history.Remove(url); _history.Insert(0, url); if (_history.Count > 200) _history.RemoveAt(_history.Count - 1); SaveData();
    }

    private void ShowStatus(string text) => StatusText.Text = text;

    private void Browser_NavigationStarting(TabItem tab, CoreWebView2NavigationStartingEventArgs e)
    {
        if (TabBar.SelectedItem != tab) return;
        _updatingAddressBox = true;
        AddressBox.Text = e.Uri;
        _updatingAddressBox = false;
        AddressSuggestionPopup.IsOpen = false;
        UpdateSecurity(e.Uri);
        ShowStatus("Yükleniyor…");
        PageProgress.Visibility = Visibility.Visible;
        PageProgress.IsIndeterminate = true;
    }

    private void Browser_NavigationCompleted(TabItem tab, CoreWebView2NavigationCompletedEventArgs e)
    {
        if (!_browsers.TryGetValue(tab, out var browser)) return;
        if (TabBar.SelectedItem == tab)
        {
            PageProgress.IsIndeterminate = false;
            PageProgress.Visibility = Visibility.Collapsed;
        }
        if (!e.IsSuccess)
        {
            if (TabBar.SelectedItem == tab) ShowStatus("Sayfa yüklenemedi: " + e.WebErrorStatus);
            return;
        }
        var previousUrl = CurrentUrl(browser);
        var sourceUrl = browser.Source?.ToString() ?? string.Empty;
        var url = previousUrl.StartsWith("ftb://", StringComparison.OrdinalIgnoreCase) &&
                  (string.IsNullOrWhiteSpace(sourceUrl) || sourceUrl.Equals("about:blank", StringComparison.OrdinalIgnoreCase))
            ? previousUrl
            : sourceUrl;
        if (string.IsNullOrWhiteSpace(url)) url = previousUrl;
        _browserUrls[browser] = url;
        if (!_privateTabs.Contains(tab) && !string.IsNullOrWhiteSpace(url) && !url.Equals("about:blank", StringComparison.OrdinalIgnoreCase)) AddHistory(url);
        UpdateTabTitle(tab);
        if (TabBar.SelectedItem == tab)
        {
            _updatingAddressBox = true;
            AddressBox.Text = url;
            _updatingAddressBox = false;
            AddressSuggestionPopup.IsOpen = false;
            UpdateSecurity(url);
            ShowStatus("Hazır");
            UpdateZoomLabel();
        }
        if (!_privateTabs.Contains(tab)) SaveSessionTabs();
    }

    private void UpdateZoomLabel()
    {
        if (CurrentBrowser != null) ZoomText.Text = $"{Math.Round(CurrentBrowser.ZoomFactor * 100)}%";
    }

    private void SetZoom(double delta)
    {
        var browser = CurrentBrowser;
        if (browser == null) return;

        var next = browser.ZoomFactor + delta;
        if (next < 0.25) next = 0.25;
        if (next > 5.0) next = 5.0;

        browser.ZoomFactor = next;
        UpdateZoomLabel();
        ShowStatus($"Yakınlaştırma: {Math.Round(next * 100)}%");
    }

    private void NewTab_Click(object sender, RoutedEventArgs e) => _ = CreateTabAsync(HomeUrl);
    private void Back_Click(object sender, RoutedEventArgs e) { if (CurrentBrowser?.CanGoBack == true) CurrentBrowser.GoBack(); }
    private void Forward_Click(object sender, RoutedEventArgs e) { if (CurrentBrowser?.CanGoForward == true) CurrentBrowser.GoForward(); }
    private void Refresh_Click(object sender, RoutedEventArgs e) => CurrentBrowser?.Reload();
    private void Go_Click(object sender, RoutedEventArgs e) => Navigate();
    private void Home_Click(object sender, RoutedEventArgs e) => NavigateBrowser(CurrentBrowser, HomeUrl);
    private void CopyUrl_Click(object sender, RoutedEventArgs e)
    {
        var url = CurrentBrowser?.Source?.ToString() ?? AddressBox.Text;
        if (string.IsNullOrWhiteSpace(url)) return;
        Clipboard.SetText(url); ShowStatus("Adres panoya kopyalandı");
    }

    private void Favorite_Click(object sender, RoutedEventArgs e)
    {
        var browser = CurrentBrowser;
        var url = browser?.Source?.ToString() ?? AddressBox.Text;
        if (string.IsNullOrWhiteSpace(url) || url.StartsWith("ftb://", StringComparison.OrdinalIgnoreCase)) return;
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https")) return;
        var title = string.IsNullOrWhiteSpace(browser?.CoreWebView2?.DocumentTitle) ? uri.Host : browser.CoreWebView2.DocumentTitle;
        _favorites.RemoveAll(x => x.Url == url); _favorites.Insert(0, new FavoriteItem(title, url)); SaveData(); RefreshFavoritesBar(); ShowStatus("Favoriye eklendi");
    }

    private void Screenshot_Click(object sender, RoutedEventArgs e) => _ = CaptureScreenshotAsync();

    private async Task CaptureScreenshotAsync()
    {
        var browser = CurrentBrowser;
        var core = browser?.CoreWebView2;
        if (core == null) { ShowStatus("Ekran görüntüsü için sayfa hazır değil"); return; }

        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "ftbBrowser");
            Directory.CreateDirectory(dir);

            Exception? lastError = null;
            for (var attempt = 1; attempt <= 3; attempt++)
            {
                var file = Path.Combine(dir, "ftbBrowser_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".png");
                try
                {
                    await Task.Delay(120 * attempt);
                    await using (var stream = new FileStream(file, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
                    {
                        await core.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png, stream);
                        await stream.FlushAsync();
                    }

                    var info = new FileInfo(file);
                    if (info.Length < 256) throw new IOException("Oluşturulan görüntü dosyası geçersiz.");

                    DownloadBar.Visibility = Visibility.Visible;
                    DownloadText.Text = "Ekran görüntüsü kaydedildi: " + info.Name;
                    ShowStatus("Ekran görüntüsü kaydedildi");
                    return;
                }
                catch (Exception ex)
                {
                    lastError = ex;
                    try { if (File.Exists(file)) File.Delete(file); } catch { }
                }
            }

            ShowStatus("Ekran görüntüsü alınamadı: " + (lastError?.Message ?? "bilinmeyen hata"));
        }
        catch (Exception ex)
        {
            ShowStatus("Ekran görüntüsü alınamadı: " + ex.Message);
            WriteError(ex);
        }
    }

    private static SolidColorBrush Brush(string hex) => new((Color)ColorConverter.ConvertFromString(hex));

    private void TabList_Click(object sender, RoutedEventArgs e)
    {
        var menu = new ContextMenu();
        foreach (var tab in TabBar.Items.OfType<TabItem>())
        {
            var header = tab.Header is StackPanel p && p.Children.Count > 1 && p.Children[1] is TextBlock t ? t.Text : "Sekme";
            var item = new MenuItem { Header = header, IsChecked = TabBar.SelectedItem == tab, Tag = tab };
            item.Click += (_, _) => TabBar.SelectedItem = (TabItem)item.Tag!;
            menu.Items.Add(item);
        }
        menu.IsOpen = true;
    }

    private void Print_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            CurrentBrowser?.CoreWebView2?.ShowPrintUI();
            ShowStatus("Yazdırma penceresi açıldı");
        }
        catch (Exception ex) { ShowStatus("Yazdırma başlatılamadı: " + ex.Message); }
    }

    private async void SavePage_Click(object sender, RoutedEventArgs e)
    {
        if (CurrentBrowser?.CoreWebView2 == null) return;
        try
        {
            await CurrentBrowser.CoreWebView2.ShowSaveAsUIAsync();
            ShowStatus("Sayfayı kaydetme penceresi açıldı");
        }
        catch (Exception ex) { ShowStatus("Sayfa kaydedilemedi: " + ex.Message); }
    }

    private void Stop_Click(object sender, RoutedEventArgs e)
    {
        try { CurrentBrowser?.CoreWebView2?.Stop(); ShowStatus("Yükleme durduruldu"); } catch { }
    }

    private void ToggleMute_Click(object sender, RoutedEventArgs e)
    {
        var core = CurrentBrowser?.CoreWebView2;
        if (core == null) return;
        core.IsMuted = !core.IsMuted;
        ShowStatus(core.IsMuted ? "Sekme sesi kapatıldı" : "Sekme sesi açıldı");
    }

    private void CopyTitle_Click(object sender, RoutedEventArgs e)
    {
        var title = CurrentBrowser?.CoreWebView2?.DocumentTitle ?? "ftbBrowser";
        Clipboard.SetText(title);
        ShowStatus("Sayfa başlığı panoya kopyalandı");
    }

    private void OpenExternal_Click(object sender, RoutedEventArgs e)
    {
        var url = CurrentBrowser?.Source?.ToString() ?? string.Empty;
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https"))
        {
            ShowStatus("Harici tarayıcıda açılacak bir web sayfası yok");
            return;
        }
        try
        {
            Process.Start(new ProcessStartInfo(uri.ToString()) { UseShellExecute = true });
            ShowStatus("Varsayılan tarayıcıda açıldı");
        }
        catch (Exception ex) { ShowStatus("Harici tarayıcı açılamadı: " + ex.Message); }
    }

    private void DownloadManager_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            CurrentBrowser?.CoreWebView2?.OpenDefaultDownloadDialog();
            ShowStatus("İndirilenler penceresi açıldı");
        }
        catch (Exception ex) { ShowStatus("İndirilenler açılamadı: " + ex.Message); }
    }

    private void BrowserTaskManager_Click(object sender, RoutedEventArgs e)
    {
        try { CurrentBrowser?.CoreWebView2?.OpenTaskManagerWindow(); ShowStatus("Tarayıcı görev yöneticisi açıldı"); } catch (Exception ex) { ShowStatus("Görev yöneticisi açılamadı: " + ex.Message); }
    }

    private async void ClearBrowsingData_Click(object sender, RoutedEventArgs e)
    {
        var core = CurrentBrowser?.CoreWebView2;
        if (core?.Profile == null) return;
        var result = MessageBox.Show(this,
            "WebView2 çerezleri, önbelleği ve diğer web verileri temizlensin mi?\n\nftbBrowser favorileri, geçmişi ve açık sekmeleri korunur.",
            "Web verilerini temizle", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (result != MessageBoxResult.Yes) return;
        try
        {
            await core.Profile.ClearBrowsingDataAsync();
            ShowStatus("Web verileri temizlendi");
        }
        catch (Exception ex) { ShowStatus("Web verileri temizlenemedi: " + ex.Message); }
    }

    private void Menu_Click(object sender, RoutedEventArgs e)
    {
        var menu = new ContextMenu { Background = (Brush)FindResource("Surface"), BorderBrush = (Brush)FindResource("BorderStrong"), BorderThickness = new Thickness(1), Padding = new Thickness(6) };
        AddModernMenuItem(menu, "new", "Yeni sekme", "Ctrl+T", () => _ = CreateTabAsync(HomeUrl));
        AddModernMenuItem(menu, "private", "Özel sekme", "Ctrl+Shift+N", () => _ = CreateTabAsync(HomeUrl, true));
        AddModernMenuItem(menu, "back", "Kapatılan sekmeyi aç", "Ctrl+Shift+T", ReopenClosedTab);
        AddModernMenuItem(menu, "copy", "Sekmeyi çoğalt", "", DuplicateCurrentTab);
        AddModernMenuItem(menu, "search", "Adres çubuğu", "Ctrl+L", () => { AddressBox.Focus(); AddressBox.SelectAll(); });
        menu.Items.Add(new Separator());
        AddModernMenuItem(menu, "search", "Google'da ara", "", () => { AddressBox.Focus(); AddressBox.SelectAll(); });
        AddModernMenuItem(menu, "search", "FTB Search", "", () => NavigateBrowser(CurrentBrowser, "ftb://search"));
        AddModernMenuItem(menu, "history", "Geçmiş", "Ctrl+H", () => NavigateBrowser(CurrentBrowser, "ftb://history"));
        AddModernMenuItem(menu, "favorite", "Favoriler", "", () => NavigateBrowser(CurrentBrowser, "ftb://favorites"));
        AddModernMenuItem(menu, "download", "İndirilenler", "Ctrl+J", () => NavigateBrowser(CurrentBrowser, "ftb://downloads"));
        AddModernMenuItem(menu, "settings", "Ayarlar", "", () => NavigateBrowser(CurrentBrowser, "ftb://settings"));
        AddModernMenuItem(menu, "games", "ftbGames", "", () => NavigateBrowser(CurrentBrowser, "ftb://games"));
        AddModernMenuItem(menu, "tools", "ftbTools", "", () => NavigateBrowser(CurrentBrowser, "ftb://tools"));
        menu.Items.Add(new Separator());
        AddModernMenuItem(menu, "screen", "Ekran görüntüsü", "", () => Screenshot_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "pdf", "PDF olarak kaydet", "", () => SaveAsPdf_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "print", "Yazdır", "Ctrl+P", () => Print_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "read", "Okuma modu", "", () => ReaderMode_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "translate", "Türkçeye çevir", "", TranslateCurrentPage);
        AddModernMenuItem(menu, "info", "Site bilgisi", "", () => SiteInfo_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "external", "Varsayılan tarayıcıda aç", "", () => OpenExternal_Click(this, new RoutedEventArgs()));
        menu.Items.Add(new Separator());
        AddModernMenuItem(menu, "new", "Yakınlaştır +", "Ctrl++", () => SetZoom(0.1));
        AddModernMenuItem(menu, "minus", "Yakınlaştır −", "Ctrl+-", () => SetZoom(-0.1));
        AddModernMenuItem(menu, "reset", "Yakınlaştırmayı sıfırla", "Ctrl+0", () => { if (CurrentBrowser != null) CurrentBrowser.ZoomFactor = 1; UpdateZoomLabel(); });
        AddModernMenuItem(menu, "fullscreen", "Tam ekran", "F11", ToggleFullscreen);
        menu.Items.Add(new Separator());
        AddModernMenuItem(menu, "clear", "Web verilerini temizle", "", () => ClearBrowsingData_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "export", "Yedek dışa aktar", "", () => ExportBackup_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "import", "Yedek içe aktar", "", () => ImportBackup_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "theme", _settings.RestoreSessionOnStartup ? "Oturum geri yükleme: Açık" : "Oturum geri yükleme: Kapalı", "", ToggleSessionRestore);
        AddModernMenuItem(menu, "theme", "Tema değiştir", "", ToggleTheme);
        AddModernMenuItem(menu, "info", "Hakkında", "", () => NavigateBrowser(CurrentBrowser, "ftb://about"));
        menu.PlacementTarget = this;
        menu.Placement = PlacementMode.MousePoint;
        menu.IsOpen = true;
    }

    private static void AddMenu(ContextMenu menu, string text, RoutedEventHandler action) { var item = new MenuItem { Header = text }; item.Click += action; menu.Items.Add(item); }

    private void ShowHistory()
    {
        var menu = new ContextMenu();
        if (_history.Count == 0) menu.Items.Add(new MenuItem { Header = "Geçmiş boş", IsEnabled = false });
        foreach (var url in _history.Take(35)) { var item = new MenuItem { Header = url, ToolTip = url }; item.Click += (_, _) => NavigateBrowser(CurrentBrowser, url); menu.Items.Add(item); }
        var clear = new MenuItem { Header = "Geçmişi temizle" }; clear.Click += (_, _) => { _history.Clear(); SaveData(); ShowStatus("Geçmiş temizlendi"); }; menu.Items.Add(new Separator()); menu.Items.Add(clear); menu.IsOpen = true;
    }

    private void ShowFavorites()
    {
        var menu = new ContextMenu();
        if (_favorites.Count == 0) menu.Items.Add(new MenuItem { Header = "Henüz favori yok", IsEnabled = false });
        foreach (var favorite in _favorites) { var item = new MenuItem { Header = favorite.Title, ToolTip = favorite.Url }; item.Click += (_, _) => NavigateBrowser(CurrentBrowser, favorite.Url); menu.Items.Add(item); }
        var clear = new MenuItem { Header = "Favorileri temizle" }; clear.Click += (_, _) => { _favorites.Clear(); SaveData(); RefreshFavoritesBar(); ShowStatus("Favoriler temizlendi"); }; menu.Items.Add(new Separator()); menu.Items.Add(clear); menu.IsOpen = true;
    }

    private void RefreshFavoritesBar()
    {
        FavoritesPanel.Children.Clear();
        if (_favorites.Count == 0) { FavoritesPanel.Children.Add(new TextBlock { Text = "☆ Favori eklemek için yıldız düğmesini kullan", Foreground = Brushes.Gray, Margin = new Thickness(8, 4, 8, 0), FontSize = 11.5 }); return; }
        foreach (var favorite in _favorites.Take(24))
        {
            var button = new Button { Content = favorite.Title, Tag = favorite.Url, Height = 26, Padding = new Thickness(10, 1, 10, 1), Margin = new Thickness(2), Background = Brushes.Transparent, BorderThickness = new Thickness(0), Foreground = Brushes.DimGray, ToolTip = favorite.Url };
            button.Click += (_, _) => NavigateBrowser(CurrentBrowser, (string)button.Tag!);
            FavoritesPanel.Children.Add(button);
        }
    }

    private static void OpenDownloads()
    {
        var downloads = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
        try
        {
            if (!Directory.Exists(downloads)) Directory.CreateDirectory(downloads);
            Process.Start(new ProcessStartInfo("explorer.exe", downloads) { UseShellExecute = true });
        }
        catch { }
    }

    private void OpenDownloads_Click(object sender, RoutedEventArgs e)
    {
        OpenDownloads();
    }

    private void TabBar_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.Source != TabBar || TabBar.SelectedItem is not TabItem) return;
        BrowserHost.Content = CurrentBrowser; UpdateAddressBar(); UpdateTabTitle(TabBar.SelectedItem as TabItem);
    }

    private void TabBar_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is not DependencyObject source) return;
        var tab = FindParent<TabItem>(source);
        if (tab == null) return;
        var menu = new ContextMenu { Background = (Brush)FindResource("Surface"), BorderBrush = (Brush)FindResource("BorderStrong"), BorderThickness = new Thickness(1), Padding = new Thickness(6) };
        AddModernMenuItem(menu, "clear", "Sekmeyi kapat", "Ctrl+W", () => CloseTab(tab));
        AddModernMenuItem(menu, "favorite", _pinnedTabs.Contains(tab) ? "Sabitlemeyi kaldır" : "Sekmeyi sabitle", "", () => TogglePinTab(tab));
        AddModernMenuItem(menu, "copy", "Sekmeyi çoğalt", "", () => DuplicateTab(tab));
        AddModernMenuItem(menu, "clear", "Diğer sekmeleri kapat", "", () => CloseOtherTabs(tab));
        AddModernMenuItem(menu, "back", "Kapatılan sekmeyi aç", "Ctrl+Shift+T", ReopenClosedTab);
        menu.PlacementTarget = this;
        menu.Placement = PlacementMode.MousePoint;
        menu.IsOpen = true;
        e.Handled = true;
    }

    private static T? FindParent<T>(DependencyObject? source) where T : DependencyObject
    {
        while (source != null) { if (source is T match) return match; source = VisualTreeHelper.GetParent(source); }
        return null;
    }

    private void DuplicateCurrentTab() { if (TabBar.SelectedItem is TabItem tab) DuplicateTab(tab); }
    private void DuplicateTab(TabItem tab) { if (_browsers.TryGetValue(tab, out var browser)) _ = CreateTabAsync(CurrentUrl(browser)); }
    private void CloseOtherTabs(TabItem keep) { foreach (var tab in TabBar.Items.OfType<TabItem>().Where(x => x != keep).ToList()) CloseTab(tab); TabBar.SelectedItem = keep; }
    private void ReopenClosedTab() { if (_closedTabs.Count == 0) { ShowStatus("Kapatılan sekme yok"); return; } _ = CreateTabAsync(_closedTabs.Pop()); }

    private void SetTabGroup(TabItem tab, string group)
    {
        if (string.IsNullOrWhiteSpace(group)) _tabGroups.Remove(tab); else _tabGroups[tab] = group;
        UpdatePinnedTabHeaders();
        ShowStatus(string.IsNullOrWhiteSpace(group) ? "Sekme grubu kaldırıldı" : "Sekme grubu: " + group);
    }

    private void TogglePinTab(TabItem tab)
    {
        if (_pinnedTabs.Contains(tab))
        {
            _pinnedTabs.Remove(tab);
            ShowStatus("Sekme sabitlemesi kaldırıldı");
        }
        else
        {
            _pinnedTabs.Add(tab);
            var index = TabBar.Items.IndexOf(tab);
            if (index > 0)
            {
                TabBar.Items.Remove(tab);
                TabBar.Items.Insert(0, tab);
            }
            ShowStatus("Sekme sabitlendi");
        }
        UpdatePinnedTabHeaders();
    }

    private void UpdatePinnedTabHeaders()
    {
        foreach (var tab in TabBar.Items.OfType<TabItem>())
        {
            if (tab.Header is not StackPanel panel || panel.Children.Count < 2 || panel.Children[1] is not TextBlock text) continue;
            var title = RemovePinPrefix(text.Text);
            title = title.Contains(" • ", StringComparison.Ordinal) ? title[(title.LastIndexOf(" • ", StringComparison.Ordinal) + 3)..] : title;
            var group = _tabGroups.TryGetValue(tab, out var groupName) && !string.IsNullOrWhiteSpace(groupName) ? groupName + " • " : string.Empty;
            text.Text = (_pinnedTabs.Contains(tab) ? "PIN • " : string.Empty) + group + title;
        }
    }

    private void TabBar_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is not DependencyObject source) return;
        var tab = FindParent<TabItem>(source);
        if (tab == null) return;
        _dragTab = tab;
        _dragStartPoint = e.GetPosition(TabBar);
    }

    private void TabBar_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (_dragTab == null || e.LeftButton != MouseButtonState.Pressed) return;
        var point = e.GetPosition(TabBar);
        if (Math.Abs(point.X - _dragStartPoint.X) < 24) return;
        var target = FindParent<TabItem>(e.OriginalSource as DependencyObject);
        if (target == null || ReferenceEquals(target, _dragTab)) return;
        if (_pinnedTabs.Contains(target) != _pinnedTabs.Contains(_dragTab)) return;
        var from = TabBar.Items.IndexOf(_dragTab);
        var to = TabBar.Items.IndexOf(target);
        if (from < 0 || to < 0) return;
        TabBar.Items.Remove(_dragTab);
        TabBar.Items.Insert(to, _dragTab);
        TabBar.SelectedItem = _dragTab;
        _dragStartPoint = point;
    }

    private void ShowModernContextMenu()
    {
        var menu = new ContextMenu
        {
            Background = (Brush)FindResource("Surface"),
            BorderBrush = (Brush)FindResource("BorderStrong"),
            BorderThickness = new Thickness(1),
            Padding = new Thickness(6)
        };
        AddModernMenuItem(menu, "back", "Geri", "Alt+Sol", () => Back_Click(this, new RoutedEventArgs()), CurrentBrowser?.CanGoBack != true);
        AddModernMenuItem(menu, "forward", "İleri", "Alt+Sağ", () => Forward_Click(this, new RoutedEventArgs()), CurrentBrowser?.CanGoForward != true);
        AddModernMenuItem(menu, "refresh", "Yenile", "F5", () => Refresh_Click(this, new RoutedEventArgs()));
        menu.Items.Add(new Separator());
        if (!string.IsNullOrWhiteSpace(_contextLink))
        {
            AddModernMenuItem(menu, "external", "Bağlantıyı yeni sekmede aç", "", () => _ = CreateTabAsync(_contextLink!));
            AddModernMenuItem(menu, "copy", "Bağlantıyı kopyala", "", () => Clipboard.SetText(_contextLink!));
        }
        if (!string.IsNullOrWhiteSpace(_contextSelection))
        {
            AddModernMenuItem(menu, "copy", "Seçimi kopyala", "", () => Clipboard.SetText(_contextSelection!));
            AddModernMenuItem(menu, "search", "Seçimi Google'da ara", "", () => NavigateBrowser(CurrentBrowser, "https://www.google.com/search?q=" + Uri.EscapeDataString(_contextSelection!)));
        }
        menu.Items.Add(new Separator());
        AddModernMenuItem(menu, "screen", "Ekran görüntüsü", "", () => Screenshot_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "pdf", "PDF olarak kaydet", "", () => SaveAsPdf_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "print", "Sayfayı yazdır", "Ctrl+P", () => Print_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "read", "Okuma modu", "", () => ReaderMode_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "translate", "Türkçeye çevir", "", TranslateCurrentPage);
        menu.Items.Add(new Separator());
        AddModernMenuItem(menu, "info", "Site bilgisi", "", () => SiteInfo_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "external", "Varsayılan tarayıcıda aç", "", () => OpenExternal_Click(this, new RoutedEventArgs()));
        AddModernMenuItem(menu, "search", "Sayfada bul", "Ctrl+F", OpenFind);
        AddModernMenuItem(menu, "sound", "Sesi aç / kapat", "Ctrl+Shift+M", () => ToggleMute_Click(this, new RoutedEventArgs()));
        menu.PlacementTarget = this;
        menu.Placement = PlacementMode.MousePoint;
        menu.IsOpen = true;
    }

    private static Geometry IconGeometry(string icon)
    {
        return icon switch
        {
            "new" or "+" => Geometry.Parse("M12,5 V19 M5,12 H19"),
            "private" => Geometry.Parse("M12,3 A9,9 0 1 0 12,21 A9,9 0 1 0 12,3 M12,8 A4,4 0 1 0 12,16 A4,4 0 1 0 12,8"),
            "back" => Geometry.Parse("M15,4 L7,12 L15,20"),
            "forward" => Geometry.Parse("M9,4 L17,12 L9,20"),
            "search" or "address" => Geometry.Parse("M10,4 A6,6 0 1 0 10,16 A6,6 0 1 0 10,4 M14.5,14.5 L20,20"),
            "copy" => Geometry.Parse("M7,7 H19 V19 H7 Z M4,4 H16 V7"),
            "history" => Geometry.Parse("M12,3 A9,9 0 1 0 12,21 A9,9 0 1 0 12,3 M12,7 V12 L16,14"),
            "favorite" => Geometry.Parse("M12,3 L14.8,8.8 L21,9.5 L16.3,13.8 L17.6,20 L12,16.9 L6.4,20 L7.7,13.8 L3,9.5 L9.2,8.8 Z"),
            "download" => Geometry.Parse("M12,4 V15 M7,11 L12,16 L17,11 M5,19 H19"),
            "settings" => Geometry.Parse("M12,3 V6 M12,18 V21 M3,12 H6 M18,12 H21 M5.6,5.6 L7.7,7.7 M16.3,16.3 L18.4,18.4 M5.6,18.4 L7.7,16.3 M16.3,7.7 L18.4,5.6 M12,8 A4,4 0 1 0 12,16 A4,4 0 1 0 12,8"),
            "games" => Geometry.Parse("M6,8 H18 C21,8 22,11 22,15 C22,18 20,20 18,18 L15,15 H9 L6,18 C4,20 2,18 2,15 C2,11 3,8 6,8 M6,11 V15 M4,13 H8 M17,12 A1,1 0 1 0 19,12 A1,1 0 1 0 17,12 M18,11 V13"),
            "tools" => Geometry.Parse("M19,4 A5,5 0 0 0 13,9 L5,17 A2,2 0 1 0 8,20 L16,12 A5,5 0 0 0 20,6 L17,7 L15,5 Z"),
            "screen" => Geometry.Parse("M4,7 H8 L10,4 H14 L16,7 H20 V19 H4 Z M12,10 A3,3 0 1 0 12,16 A3,3 0 1 0 12,10"),
            "pdf" => Geometry.Parse("M6,3 H16 L20,7 V21 H6 Z M16,3 V8 H21"),
            "print" => Geometry.Parse("M6,8 V4 H18 V8 M5,10 H19 V18 H5 Z M8,15 H16 V21 H8 Z"),
            "read" => Geometry.Parse("M5,4 H11 A3,3 0 0 1 14,7 V20 A3,3 0 0 0 11,17 H5 Z M19,4 H13 A3,3 0 0 0 10,7 V20 A3,3 0 0 1 13,17 H19 Z"),
            "translate" => Geometry.Parse("M12,2 A10,10 0 1 0 12,22 A10,10 0 1 0 12,2 M2,12 H22 M12,2 C8,7 8,17 12,22 M12,2 C16,7 16,17 12,22"),
            "info" => Geometry.Parse("M12,2 A10,10 0 1 0 12,22 A10,10 0 1 0 12,2 M12,10 V17 M12,6 V8"),
            "external" => Geometry.Parse("M14,4 H20 V10 M19,5 L10,14 M18,13 V20 H4 V6 H11"),
            "minus" => Geometry.Parse("M5,12 H19"),
            "reset" => Geometry.Parse("M8,4 H16 V20 H8 Z M10,8 H14 M10,12 H14 M10,16 H14"),
            "fullscreen" => Geometry.Parse("M4,9 V4 H9 M15,4 H20 V9 M20,15 V20 H15 M9,20 H4 V15"),
            "clear" => Geometry.Parse("M6,6 L18,18 M18,6 L6,18"),
            "export" => Geometry.Parse("M12,3 V15 M8,7 L12,3 L16,7 M5,13 V20 H19 V13"),
            "import" => Geometry.Parse("M12,17 V5 M8,13 L12,17 L16,13 M5,4 V21 H19 V4"),
            "theme" => Geometry.Parse("M12,3 A9,9 0 1 0 21,12 A7,7 0 0 1 12,3"),
            "refresh" => Geometry.Parse("M19,8 A8,8 0 1 0 20,13 M19,4 V9 H14"),
            "sound" => Geometry.Parse("M4,10 H8 L12,6 V18 L8,14 H4 Z M15,9 A4,4 0 0 1 15,15 M17,7 A7,7 0 0 1 17,17"),
            _ => Geometry.Parse("M4,12 H20")
        };
    }

    private static void AddModernMenuItem(ContextMenu menu, string icon, string text, string gesture, Action action, bool disabled = false)
    {
        var row = new Grid { VerticalAlignment = VerticalAlignment.Center, MinHeight = 30 };
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(30) });
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var iconPath = new System.Windows.Shapes.Path
        {
            Data = IconGeometry(icon), Width = 17, Height = 17, Stretch = Stretch.Uniform,
            Fill = Brushes.Transparent, Stroke = (Brush)Application.Current.MainWindow!.FindResource("IconText"),
            StrokeThickness = 1.55, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round, StrokeLineJoin = PenLineJoin.Round,
            HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
        };
        var iconBox = new Border { Width = 28, Height = 28, CornerRadius = new CornerRadius(8), Background = Brushes.Transparent, Child = iconPath, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center };
        Grid.SetColumn(iconBox, 0); row.Children.Add(iconBox);
        var label = new TextBlock { Text = text, Margin = new Thickness(4, 0, 18, 0), VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5, Foreground = (Brush)Application.Current.MainWindow!.FindResource("Text") };
        Grid.SetColumn(label, 1); row.Children.Add(label);
        if (!string.IsNullOrWhiteSpace(gesture))
        {
            var key = new TextBlock { Text = gesture, Margin = new Thickness(0, 0, 3, 0), VerticalAlignment = VerticalAlignment.Center, FontSize = 11.5, Foreground = (Brush)Application.Current.MainWindow!.FindResource("Muted") };
            Grid.SetColumn(key, 2); row.Children.Add(key);
        }
        var item = new MenuItem { Header = row, IsEnabled = !disabled, MinHeight = 36, Padding = new Thickness(7, 4, 7, 4), Background = Brushes.Transparent, Foreground = (Brush)Application.Current.MainWindow!.FindResource("Text") };
        item.Click += (_, _) => action();
        menu.Items.Add(item);
    }

    private void TranslateCurrentPage()
    {
        var browser = CurrentBrowser;
        if (browser == null) { ShowStatus("Çevrilecek bir sayfa yok"); return; }
        var url = CurrentUrl(browser);
        if (!IsWebUrl(url)) { ShowStatus("Çevrilecek bir web sayfası yok"); return; }
        NavigateBrowser(CurrentBrowser, "https://translate.google.com/translate?sl=auto&tl=tr&u=" + Uri.EscapeDataString(url));
    }

    private void SiteInfo_Click(object sender, RoutedEventArgs e)
    {
        var url = CurrentBrowser == null ? AddressBox.Text : CurrentUrl(CurrentBrowser);
        if (string.IsNullOrWhiteSpace(url)) return;
        var lines = new List<string> { "Adres: " + url };
        if (Uri.TryCreate(url, UriKind.Absolute, out var uri))
        {
            lines.Add("Şema: " + uri.Scheme);
            lines.Add("Alan adı: " + (string.IsNullOrWhiteSpace(uri.Host) ? "Yok" : uri.Host));
            lines.Add("HTTPS: " + (uri.Scheme.Equals("https", StringComparison.OrdinalIgnoreCase) ? "Evet" : "Hayır"));
        }
        MessageBox.Show(this, string.Join(Environment.NewLine, lines), "Site bilgisi", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private async void ReaderMode_Click(object sender, RoutedEventArgs e)
    {
        var browser = CurrentBrowser;
        if (browser?.CoreWebView2 == null) return;
        try
        {
            var script = "(() => { const b = document.body; return b ? (b.innerText || '').slice(0, 30000) : ''; })()";
            var result = await browser.CoreWebView2.ExecuteScriptAsync(script);
            var text = JsonSerializer.Deserialize<string>(result) ?? string.Empty;
            if (string.IsNullOrWhiteSpace(text)) { ShowStatus("Okuma modu için metin bulunamadı"); return; }
            var html = FtbPageShell("Okuma Modu", "<div class='headRow'><div><div class='kicker'>ftbBrowser</div><h1>Okuma Modu</h1><p>Geri düğmesiyle önceki sayfaya dönebilirsin.</p></div></div><article class='article'>" + Html(text).Replace("\n", "<br>") + "</article>");
            browser.CoreWebView2.NavigateToString(html);
            _browserUrls[browser] = "ftb://reader";
            UpdateAddressBar();
            ShowStatus("Okuma modu hazır");
        }
        catch (Exception ex) { ShowStatus("Okuma modu açılamadı: " + ex.Message); }
    }

    private async void SaveAsPdf_Click(object sender, RoutedEventArgs e)
    {
        var browser = CurrentBrowser;
        if (browser?.CoreWebView2 == null) return;
        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ftbBrowser");
            Directory.CreateDirectory(dir);
            var file = Path.Combine(dir, "ftbBrowser_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".pdf");
            var ok = await browser.CoreWebView2.PrintToPdfAsync(file);
            ShowStatus(ok ? "PDF kaydedildi: " + Path.GetFileName(file) : "PDF oluşturulamadı");
        }
        catch (Exception ex) { ShowStatus("PDF oluşturulamadı: " + ex.Message); }
    }

    private void AddressBox_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { Navigate(); e.Handled = true; } }
    private void OpenFind() { FindBar.Visibility = Visibility.Visible; FindBox.Focus(); FindBox.SelectAll(); }
    private void CloseFind_Click(object sender, RoutedEventArgs e) { FindBar.Visibility = Visibility.Collapsed; FindBox.Clear(); }
    private async void FindBox_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { await FindTextAsync(false); e.Handled = true; } else if (e.Key == Key.Escape) { CloseFind_Click(sender, e); e.Handled = true; } }
    private async void FindNext_Click(object sender, RoutedEventArgs e) => await FindTextAsync(false);
    private async void FindPrev_Click(object sender, RoutedEventArgs e) => await FindTextAsync(true);

    private async Task FindTextAsync(bool backwards)
    {
        if (CurrentBrowser?.CoreWebView2 == null || string.IsNullOrWhiteSpace(FindBox.Text)) return;
        var term = JsonSerializer.Serialize(FindBox.Text);
        var script = backwards ? $"window.find({term}, false, true, true, false, false, false);" : $"window.find({term}, false, false, true, false, false, false);";
        try { await CurrentBrowser.CoreWebView2.ExecuteScriptAsync(script); ShowStatus("Aranıyor: " + FindBox.Text); } catch (Exception ex) { ShowStatus("Arama hatası: " + ex.Message); }
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState.Minimized;
    }

    private void MaximizeButton_Click(object sender, RoutedEventArgs e)
    {
        ToggleMaximize();
    }

    private void CloseWindowButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left) return;
        if (e.ClickCount == 2)
        {
            ToggleMaximize();
            return;
        }
        if (WindowState == WindowState.Maximized) return;
        try { DragMove(); } catch (InvalidOperationException) { }
    }

    private void ToggleMaximize()
    {
        WindowState = WindowState == WindowState.Maximized
            ? WindowState.Normal
            : WindowState.Maximized;
        UpdateWindowControlState();
    }

    private void Window_StateChanged(object? sender, EventArgs e)
    {
        UpdateWindowControlState();
    }

    private void UpdateWindowControlState()
    {
        if (MaximizeButton == null) return;
        var maximized = WindowState == WindowState.Maximized;
        MaximizeButton.Content = "□";
        MaximizeButton.ToolTip = maximized ? "Önceki boyuta dön" : "Ekranı kapla";
    }

    private void ToggleFullscreen()
    {
        if (!_trueFullscreen)
        {
            _fullscreenPreviousState = WindowState;
            _trueFullscreen = true;
            WindowTitleBar.Visibility = Visibility.Collapsed;
            TopChrome.Visibility = Visibility.Collapsed;
            StatusBarControl.Visibility = Visibility.Collapsed;
            WindowState = WindowState.Maximized;
            ShowStatus("Tam ekran");
        }
        else
        {
            _trueFullscreen = false;
            WindowTitleBar.Visibility = Visibility.Visible;
            TopChrome.Visibility = Visibility.Visible;
            StatusBarControl.Visibility = Visibility.Visible;
            WindowState = _fullscreenPreviousState;
            ShowStatus("Tam ekrandan çıkıldı");
        }
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift))
        {
            if (e.Key == Key.T) { ReopenClosedTab(); e.Handled = true; return; }
            if (e.Key == Key.M) { ToggleMute_Click(sender, new RoutedEventArgs()); e.Handled = true; return; }
            if (e.Key == Key.S) { SavePage_Click(sender, new RoutedEventArgs()); e.Handled = true; return; }
            if (e.Key == Key.P) { SaveAsPdf_Click(sender, new RoutedEventArgs()); e.Handled = true; return; }
            if (e.Key == Key.Q) { NavigateBrowser(CurrentBrowser, "ftb://qr"); e.Handled = true; return; }
            if (e.Key == Key.U) { ReaderMode_Click(sender, new RoutedEventArgs()); e.Handled = true; return; }
            if (e.Key == Key.L) { RestoreSessionTabs(); e.Handled = true; return; }
            if (e.Key == Key.Delete) { ClearBrowsingData_Click(sender, new RoutedEventArgs()); e.Handled = true; return; }
            if (e.Key == Key.V)
            {
                try { AddressBox.Text = Clipboard.GetText(); Navigate(); } catch { }
                e.Handled = true; return;
            }
            if (e.Key == Key.PageUp) { SelectRelativeTab(-1); e.Handled = true; return; }
            if (e.Key == Key.PageDown) { SelectRelativeTab(1); e.Handled = true; return; }
        }

        if (Keyboard.Modifiers == ModifierKeys.Alt && e.Key == Key.Home) { NavigateBrowser(CurrentBrowser, HomeUrl); e.Handled = true; return; }
        if (Keyboard.Modifiers == ModifierKeys.Alt && e.Key == Key.Left) { Back_Click(sender, new RoutedEventArgs()); e.Handled = true; return; }
        if (Keyboard.Modifiers == ModifierKeys.Alt && e.Key == Key.Right) { Forward_Click(sender, new RoutedEventArgs()); e.Handled = true; return; }

        if (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift) && e.Key == Key.N) { _ = CreateTabAsync(HomeUrl, true); e.Handled = true; return; }

        if (Keyboard.Modifiers == ModifierKeys.Control)
        {
            if (e.Key >= Key.D1 && e.Key <= Key.D9)
            {
                var index = (int)e.Key - (int)Key.D1;
                if (index < TabBar.Items.Count) TabBar.SelectedIndex = index;
                e.Handled = true; return;
            }
            if (e.Key == Key.L) { AddressBox.Focus(); AddressBox.SelectAll(); e.Handled = true; return; }
            if (e.Key == Key.K) { ShowCommandPalette(); e.Handled = true; return; }
            switch (e.Key)
            {
                case Key.T: _ = CreateTabAsync(HomeUrl); e.Handled = true; break;
                case Key.W: if (TabBar.SelectedItem is TabItem tab) CloseTab(tab); e.Handled = true; break;
                case Key.R: CurrentBrowser?.Reload(); e.Handled = true; break;
                case Key.D: Favorite_Click(sender, new RoutedEventArgs()); e.Handled = true; break;
                case Key.F: OpenFind(); e.Handled = true; break;
                case Key.H: NavigateBrowser(CurrentBrowser, "ftb://history"); e.Handled = true; break;
                case Key.P: Print_Click(sender, new RoutedEventArgs()); e.Handled = true; break;
                case Key.J: NavigateBrowser(CurrentBrowser, "ftb://downloads"); e.Handled = true; break;
                case Key.PageUp: SelectRelativeTab(-1); e.Handled = true; break;
                case Key.PageDown: SelectRelativeTab(1); e.Handled = true; break;
                case Key.D0: case Key.NumPad0: if (CurrentBrowser != null) CurrentBrowser.ZoomFactor = 1.0; UpdateZoomLabel(); e.Handled = true; break;
                case Key.OemPlus: case Key.Add: SetZoom(.1); e.Handled = true; break;
                case Key.OemMinus: case Key.Subtract: SetZoom(-.1); e.Handled = true; break;
            }
        }
        else if (e.Key == Key.F5) { CurrentBrowser?.Reload(); e.Handled = true; }
        else if (e.Key == Key.F6) { AddressBox.Focus(); AddressBox.SelectAll(); e.Handled = true; }
        else if (e.Key == Key.F7) { NavigateBrowser(CurrentBrowser, "ftb://tools"); e.Handled = true; }
        else if (e.Key == Key.F11) { ToggleFullscreen(); e.Handled = true; }
        else if (e.Key == Key.F12) { CurrentBrowser?.CoreWebView2?.OpenDevToolsWindow(); e.Handled = true; }
        else if (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift) && e.Key == Key.M) { ToggleMute_Click(sender, new RoutedEventArgs()); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Shift && e.Key == Key.Escape) { BrowserTaskManager_Click(sender, new RoutedEventArgs()); e.Handled = true; }
        else if (e.Key == Key.Escape && _commandPaletteOpen) { CloseCommandPalette(); e.Handled = true; }
        else if (e.Key == Key.Escape && FindBar.Visibility == Visibility.Visible) { FindBar.Visibility = Visibility.Collapsed; e.Handled = true; }
    }

    private void SelectRelativeTab(int delta)
    {
        if (TabBar.Items.Count == 0) return;
        var current = TabBar.SelectedIndex;
        if (current < 0) current = 0;
        var next = (current + delta) % TabBar.Items.Count;
        if (next < 0) next += TabBar.Items.Count;
        TabBar.SelectedIndex = next;
    }

    private string SettingsFile => Path.Combine(_dataDir, "settings.json");

    private void LoadSettings()
    {
        try
        {
            Directory.CreateDirectory(_dataDir);
            if (File.Exists(SettingsFile))
            {
                _settings = JsonSerializer.Deserialize<BrowserSettings>(File.ReadAllText(SettingsFile)) ?? new BrowserSettings("system", true);
            }
        }
        catch { _settings = new BrowserSettings("system", true); }
        ApplyTheme(_settings.Theme);
    }

    private void SaveSettings()
    {
        try
        {
            Directory.CreateDirectory(_dataDir);
            File.WriteAllText(SettingsFile, JsonSerializer.Serialize(_settings, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void CleanupPrivateProfiles()
    {
        try
        {
            var root = Path.Combine(_dataDir, "Private");
            if (!Directory.Exists(root)) return;
            foreach (var dir in Directory.GetDirectories(root))
            {
                try { Directory.Delete(dir, true); } catch { }
            }
        }
        catch { }
    }

    private List<string> GetRestorableSessionUrls()
    {
        try
        {
            var file = Path.Combine(_dataDir, "session.json");
            if (!File.Exists(file)) return [];
            var urls = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(file)) ?? [];
            return urls.Where(IsWebUrl).Distinct(StringComparer.OrdinalIgnoreCase).Take(12).ToList();
        }
        catch { return []; }
    }

    private void ApplyTheme(string theme)
    {
        theme = (theme ?? "system").Trim().ToLowerInvariant();
        if (theme == "system")
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                var value = key?.GetValue("AppsUseLightTheme");
                theme = value is int i && i == 0 ? "dark" : "light";
            }
            catch { theme = "light"; }
        }
        _darkTheme = theme == "dark";
        var colors = theme switch
        {
            "purple" => new Dictionary<string,string>{{"WindowBg","#F4F0FA"},{"ChromeBg","#FBF8FE"},{"Surface","#FFFFFF"},{"SurfaceAlt","#F3EEF8"},{"Border","#E0D7EB"},{"BorderStrong","#D6CBE4"},{"Text","#241B31"},{"Muted","#796A89"},{"IconText","#655276"},{"IconHover","#EFE7FF"},{"IconPressed","#E3D5FB"},{"PillBg","#F0EAF7"},{"PillHover","#E8DFF2"},{"TabBg","#EEE7F4"}},
            "green" => new Dictionary<string,string>{{"WindowBg","#EFF7F2"},{"ChromeBg","#F7FCF9"},{"Surface","#FFFFFF"},{"SurfaceAlt","#EEF7F1"},{"Border","#D4E6DA"},{"BorderStrong","#C8DDD0"},{"Text","#173023"},{"Muted","#6A8273"},{"IconText","#466955"},{"IconHover","#E1F0E6"},{"IconPressed","#D2E7D9"},{"PillBg","#EAF4EE"},{"PillHover","#E0EFE6"},{"TabBg","#E5F1E9"}},
            "blue" => new Dictionary<string,string>{{"WindowBg","#EEF4FC"},{"ChromeBg","#F7FAFE"},{"Surface","#FFFFFF"},{"SurfaceAlt","#EEF4FB"},{"Border","#D5E0EF"},{"BorderStrong","#C9D7E8"},{"Text","#142335"},{"Muted","#6D8198"},{"IconText","#49627D"},{"IconHover","#E2EEFF"},{"IconPressed","#D5E5FF"},{"PillBg","#E9F1FB"},{"PillHover","#DFEAF7"},{"TabBg","#E5EEF8"}},
            "dark" => new Dictionary<string,string>{{"WindowBg","#101827"},{"ChromeBg","#141E2E"},{"Surface","#182235"},{"SurfaceAlt","#111B2B"},{"Border","#2A3950"},{"BorderStrong","#34445C"},{"Text","#EEF4FF"},{"Muted","#9AABC1"},{"IconText","#B9C7DA"},{"IconHover","#22304A"},{"IconPressed","#2A3B58"},{"PillBg","#202D42"},{"PillHover","#2B3B55"},{"TabBg","#202D42"}},
            _ => new Dictionary<string,string>{{"WindowBg","#EEF3F8"},{"ChromeBg","#F7F9FC"},{"Surface","#FFFFFF"},{"SurfaceAlt","#F0F4F9"},{"Border","#DCE4ED"},{"BorderStrong","#D6DFE9"},{"Text","#152033"},{"Muted","#708096"},{"IconText","#53647A"},{"IconHover","#E9EEFF"},{"IconPressed","#DDE5FF"},{"PillBg","#EEF2F8"},{"PillHover","#E4E9F3"},{"TabBg","#EAF0F6"}}
        };
        colors["Accent"] = theme == "purple" ? "#8B5CF6" : theme == "green" ? "#16A34A" : theme == "blue" ? "#2563EB" : "#4D5DFF";
        colors["AccentHover"] = theme == "purple" ? "#7C3AED" : theme == "green" ? "#15803D" : theme == "blue" ? "#1D4ED8" : "#3E4DEA";
        colors["AccentPressed"] = theme == "purple" ? "#6D28D9" : theme == "green" ? "#166534" : theme == "blue" ? "#1E40AF" : "#3544D0";
        colors["SuccessBg"] = _darkTheme ? "#153022" : "#EEF8F2";
        colors["SuccessBorder"] = _darkTheme ? "#285C3F" : "#CAE6D5";
        colors["SuccessText"] = _darkTheme ? "#A9E5BD" : "#2D6947";
        foreach (var pair in colors) Resources[pair.Key] = Brush(pair.Value);
        _settings = _settings with { Theme = theme };
        SaveSettings();
        ShowStatus("Tema: " + theme);
    }

    private void LoadData()
    {
        try
        {
            Directory.CreateDirectory(_dataDir);
            var file = Path.Combine(_dataDir, "data.json");
            if (File.Exists(file))
            {
                var data = JsonSerializer.Deserialize<BrowserData>(File.ReadAllText(file));
                if (data != null) { _history.AddRange(data.History ?? []); _favorites.AddRange(data.Favorites ?? []); }
            }
        }
        catch { }
    }

    private void SaveData()
    {
        try
        {
            Directory.CreateDirectory(_dataDir);
            var data = new BrowserData(_history, _favorites);
            File.WriteAllText(Path.Combine(_dataDir, "data.json"), JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void SaveSessionTabs()
    {
        if (_closing) return;
        try
        {
            Directory.CreateDirectory(_dataDir);
            var urls = new List<string>();
            foreach (var tab in TabBar.Items.OfType<TabItem>())
            {
                if (!_browsers.TryGetValue(tab, out var browser)) continue;
                if (_privateTabs.Contains(tab)) continue;
                var url = CurrentUrl(browser);
                if (Uri.TryCreate(url, UriKind.Absolute, out var uri) && (uri.Scheme is "http" or "https")) urls.Add(uri.ToString());
                if (urls.Count >= 12) break;
            }
            File.WriteAllText(Path.Combine(_dataDir, "session.json"), JsonSerializer.Serialize(urls));
        }
        catch { }
    }

    private async void RestoreSessionTabs()
    {
        try
        {
            var file = Path.Combine(_dataDir, "session.json");
            if (!File.Exists(file)) { ShowStatus("Kayıtlı oturum bulunamadı"); return; }
            var urls = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(file)) ?? [];
            urls = urls.Where(IsWebUrl).Distinct(StringComparer.OrdinalIgnoreCase).Take(12).ToList();
            if (urls.Count == 0) { ShowStatus("Kayıtlı web sekmesi bulunamadı"); return; }
            foreach (var url in urls) await CreateTabAsync(url);
            ShowStatus(urls.Count + " sekme geri yüklendi");
        }
        catch (Exception ex) { ShowStatus("Oturum geri yüklenemedi: " + ex.Message); }
    }

    private static bool IsWebUrl(string? url)
        => Uri.TryCreate(url, UriKind.Absolute, out var uri) && (uri.Scheme is "http" or "https");

    private void ClearDownloadHistory()
    {
        _downloads.Clear();
        SaveDownloads();
        ShowStatus("İndirme geçmişi temizlendi");
    }

    private void ToggleTheme()
    {
        var current = _settings.Theme;
        var next = current switch { "light" => "dark", "dark" => "blue", "blue" => "purple", "purple" => "green", _ => "light" };
        ApplyTheme(next);
    }

    private void SetTheme(string theme) => ApplyTheme(theme);

    private void ToggleSessionRestore()
    {
        _settings = _settings with { RestoreSessionOnStartup = !_settings.RestoreSessionOnStartup };
        SaveSettings();
        ShowStatus(_settings.RestoreSessionOnStartup ? "Oturum geri yükleme açıldı" : "Oturum geri yükleme kapatıldı");
    }

    private void ExportBackup_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dialog = new SaveFileDialog { Filter = "ftbBrowser yedeği (*.json)|*.json", FileName = "ftbBrowser-backup.json" };
            if (dialog.ShowDialog() != true) return;
            var backup = new BrowserBackup(_settings, _history.ToList(), _favorites.ToList());
            File.WriteAllText(dialog.FileName, JsonSerializer.Serialize(backup, new JsonSerializerOptions { WriteIndented = true }));
            ShowStatus("Yedek dışa aktarıldı");
        }
        catch (Exception ex) { ShowStatus("Yedek oluşturulamadı: " + ex.Message); }
    }

    private void ImportBackup_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dialog = new OpenFileDialog { Filter = "ftbBrowser yedeği (*.json)|*.json" };
            if (dialog.ShowDialog() != true) return;
            var backup = JsonSerializer.Deserialize<BrowserBackup>(File.ReadAllText(dialog.FileName));
            if (backup == null) { ShowStatus("Geçersiz yedek"); return; }
            _settings = backup.Settings ?? new BrowserSettings("system", true);
            _history.Clear(); _history.AddRange(backup.History ?? []);
            _favorites.Clear(); _favorites.AddRange(backup.Favorites ?? []);
            SaveData(); SaveSettings(); RefreshFavoritesBar(); ApplyTheme(_settings.Theme);
            ShowStatus("Yedek içe aktarıldı");
        }
        catch (Exception ex) { ShowStatus("Yedek yüklenemedi: " + ex.Message); }
    }

    private void OpenDownloadedFile(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        try
        {
            if (!File.Exists(path)) { ShowStatus("Dosya artık bulunamadı"); return; }
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }
        catch (Exception ex) { ShowStatus("Dosya açılamadı: " + ex.Message); }
    }

    private void LoadDownloads()
    {
        try
        {
            var file = Path.Combine(_dataDir, "downloads.json");
            if (!File.Exists(file)) return;
            var data = JsonSerializer.Deserialize<List<DownloadItem>>(File.ReadAllText(file));
            if (data != null) _downloads.AddRange(data.Take(40));
        }
        catch { }
    }

    private void SaveDownloads()
    {
        try
        {
            Directory.CreateDirectory(_dataDir);
            File.WriteAllText(Path.Combine(_dataDir, "downloads.json"), JsonSerializer.Serialize(_downloads, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void DisposeBrowsers()
    {
        if (_closing) return;
        SaveData();
        SaveDownloads();
        SaveSessionTabs();
        _closing = true;
        _downloadPollTimer.Stop();
        foreach (var browser in _browsers.Values) { try { browser.Dispose(); } catch { } }
        _browsers.Clear();
        _browserUrls.Clear();
    }

    private void ShowStartupError(Exception ex)
    {
        var panel = new StackPanel { Margin = new Thickness(30), VerticalAlignment = VerticalAlignment.Center };
        panel.Children.Add(new TextBlock { Text = "ftbBrowser başlatılamadı", FontSize = 28, FontWeight = FontWeights.Bold, Foreground = Brush("#182337"), Margin = new Thickness(0,0,0,10) });
        panel.Children.Add(new TextBlock { Text = ex.Message, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DimGray, Margin = new Thickness(0,0,0,15) });
        panel.Children.Add(new TextBlock { Text = "WebView2 Runtime kurulumu veya Windows güvenliği engelliyor olabilir.", Foreground = Brushes.Gray });
        BrowserHost.Content = new Border { Background = Brushes.White, Child = panel };
    }

    private void WriteError(Exception ex)
    {
        try { Directory.CreateDirectory(_dataDir); File.WriteAllText(Path.Combine(_dataDir, "last-error.txt"), ex.ToString()); } catch { }
    }

    private void OpenErrorLog_Click(object sender, RoutedEventArgs e)
    {
        var file = Path.Combine(_dataDir, "last-error.txt");
        try
        {
            Directory.CreateDirectory(_dataDir);
            if (!File.Exists(file)) File.WriteAllText(file, "Henüz kayıtlı hata yok.");
            Process.Start(new ProcessStartInfo("notepad.exe", file) { UseShellExecute = true });
        }
        catch (Exception ex) { ShowStatus("Hata kaydı açılamadı: " + ex.Message); }
    }

    private void OpenDataFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Directory.CreateDirectory(_dataDir);
            Process.Start(new ProcessStartInfo("explorer.exe", _dataDir) { UseShellExecute = true });
        }
        catch (Exception ex) { ShowStatus("Veri klasörü açılamadı: " + ex.Message); }
    }

    private void DownloadPollTimer_Tick(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_activeDownloadPath)) { _downloadPollTimer.Stop(); return; }
        try
        {
            if (!File.Exists(_activeDownloadPath)) return;
            var info = new FileInfo(_activeDownloadPath);
            var size = info.Length;
            DownloadText.Text = $"İndiriliyor: {Path.GetFileName(_activeDownloadPath)} • {FormatBytes(size)}";
            if (size == _lastDownloadSize) _stableDownloadTicks++; else _stableDownloadTicks = 0;
            _lastDownloadSize = size;
            if (_stableDownloadTicks >= 6 && size > 0)
            {
                _downloadPollTimer.Stop();
                DownloadText.Text = $"İndirme tamamlandı: {Path.GetFileName(_activeDownloadPath)} • {FormatBytes(size)}";
                ShowStatus("İndirme tamamlandı");
            }
        }
        catch { }
    }

    private static string FormatBytes(long bytes)
    {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024d).ToString("0.0") + " KB";
        if (bytes < 1024L * 1024L * 1024L) return (bytes / (1024d * 1024d)).ToString("0.0") + " MB";
        return (bytes / (1024d * 1024d * 1024d)).ToString("0.0") + " GB";
    }

    private void OpenLastDownload_Click(object sender, RoutedEventArgs e) => OpenDownloadedFile(_activeDownloadPath);

    private void CloseDownloadBar_Click(object sender, RoutedEventArgs e)
    {
        _downloadPollTimer.Stop();
        DownloadBar.Visibility = Visibility.Collapsed;
    }

    private sealed record BrowserSettings(string Theme, bool RestoreSessionOnStartup);
    private sealed record LayoutPreferences(bool VerticalTabs);
    private sealed record BrowserBackup(BrowserSettings? Settings, List<string>? History, List<FavoriteItem>? Favorites);
    private sealed record FavoriteItem(string Title, string Url);
    private sealed record DownloadItem(string FileName, string Path, string Time);
    private sealed record BrowserData(List<string> History, List<FavoriteItem> Favorites);
}
