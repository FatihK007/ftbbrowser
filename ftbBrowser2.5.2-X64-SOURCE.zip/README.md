# ftbBrowser 2.5.2 - X64

Windows x64 kaynak paketi.

## Bu sürümde
- 2.5.x arayüz hata düzeltmeleri
- gerçek vektör toolbar/menu ikonları
- daha sağlam ekran görüntüsü alma ve PNG doğrulaması
- x64 self-contained single-file publish
- ftbGames + ftbTools dahili HTML sayfaları EXE içine EmbeddedResource olarak gömülü
- sekme grupları, özel sekme, dikey sekmeler, yan panel, komut paleti ve tema altyapısı

## Derleme
`build-exe.bat`

Çıktı:
`publish\\ftbBrowser2.5.2.exe`
