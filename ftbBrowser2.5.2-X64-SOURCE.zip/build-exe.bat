@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ftbBrowser 2.5.2 - Windows X64
if exist bin rmdir /s /q bin
if exist obj rmdir /s /q obj
if exist publish rmdir /s /q publish

dotnet restore ftbBrowser2.5.2.csproj -r win-x64
if errorlevel 1 goto :fail
dotnet publish ftbBrowser2.5.2.csproj -c Release -r win-x64 --self-contained true -p:PlatformTarget=x64 -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -p:DebugType=None -p:DebugSymbols=false -o publish
if errorlevel 1 goto :fail
echo BASARILI: publish\ftbBrowser2.5.2.exe
pause
exit /b 0
:fail
echo DERLEME BASARISIZ.
pause
exit /b 1
